#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$HOME/eli_ar_avatar_kit}"
PY="${PYTHON:-python3}"

echo "[+] Creating AR/avatar environment at: $ROOT"
mkdir -p "$ROOT"
cd "$ROOT"

if ! command -v "$PY" >/dev/null 2>&1; then
  echo "[-] python3 not found. Install Python first."
  exit 1
fi

sudo apt-get update
sudo apt-get install -y \
  python3-venv python3-dev python3-pip \
  v4l-utils x11-xserver-utils \
  libgl1 libglib2.0-0 libxcb-xinerama0 libxkbcommon-x11-0

$PY -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip wheel setuptools
python -m pip install -r requirements.txt

echo
printf '[+] Done. Activate with:\n  cd %q && source .venv/bin/activate\n' "$ROOT"
echo '[+] Check webcam devices with: v4l2-ctl --list-devices'
echo '[+] Check monitors/projector geometry with: xrandr --listmonitors && xrandr'

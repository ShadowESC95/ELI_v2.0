# ELI AR Avatar Kit

This package contains a small Linux/Python OpenCV AR stack for ELI:

- `scripts/eli_avatar_generator.py` — creates an ELI avatar image.
- `scripts/ar_mirror.py` — software AR mirror using webcam + monitor.
- `scripts/ar_projector_cast.py` — projector/fullscreen AR cast for a second monitor/projector.
- `scripts/generate_aruco_marker.py` — printable ArUco marker used to anchor the AR object.
- `assets/eli_avatar.png` — generated default ELI avatar.
- `assets/aruco_6x6_250_id23.png` — generated default marker.

## 1. Install

```bash
cd ~/Downloads/eli_ar_avatar_kit
chmod +x install_eli_ar_avatar.sh scripts/*.py
./install_eli_ar_avatar.sh "$PWD"
source .venv/bin/activate
```

## 2. Generate/refresh ELI avatar

Procedural/offline:

```bash
python scripts/eli_avatar_generator.py \
  --backend procedural \
  --out assets/eli_avatar.png \
  --size 1024 \
  --seed 95
```

Optional local Diffusers backend:

```bash
python -m pip install -r requirements_diffusion.txt
python scripts/eli_avatar_generator.py \
  --backend diffusers \
  --model /path/to/local/diffusers/model \
  --out assets/eli_avatar.png
```

## 3. Run software AR mirror

```bash
python scripts/ar_mirror.py \
  --camera 0 \
  --asset assets/eli_avatar.png
```

With ArUco marker anchoring:

```bash
python scripts/generate_aruco_marker.py --id 23 --out assets/aruco_6x6_250_id23.png
python scripts/ar_mirror.py \
  --camera 0 \
  --asset assets/eli_avatar.png \
  --use-marker
```

Print `assets/aruco_6x6_250_id23.png`, place it on a desk/wall/surface, and point the webcam at it.

## 4. Run projector AR cast

Find projector monitor offset:

```bash
xrandr --listmonitors
xrandr
```

Example where projector begins at X=1920, Y=0:

```bash
python scripts/ar_projector_cast.py \
  --camera 0 \
  --asset assets/eli_avatar.png \
  --screen-x 1920 \
  --screen-y 0 \
  --fullscreen \
  --mode object-only
```

Composite webcam + AR on projector:

```bash
python scripts/ar_projector_cast.py \
  --camera 0 \
  --asset assets/eli_avatar.png \
  --screen-x 1920 \
  --screen-y 0 \
  --fullscreen \
  --mode composite
```

Marker-anchored projector object:

```bash
python scripts/ar_projector_cast.py \
  --camera 0 \
  --asset assets/eli_avatar.png \
  --screen-x 1920 \
  --screen-y 0 \
  --fullscreen \
  --mode object-only \
  --use-marker
```

## Controls

- `q` or `ESC` — quit
- `s` — save screenshot
- `h` — toggle HUD
- `m` — toggle mirror
- `a` — toggle marker anchoring
- `c` — projector script only: switch object-only/composite mode
- `[` / `]` — opacity down/up
- `-` / `=` — scale down/up
- Arrow keys — move overlay when marker mode is not locked

## Notes

This is practical AR/projection compositing, not full spatial projection mapping. For physically accurate projection onto irregular surfaces, the next stage is camera calibration + projector calibration + homography/mesh warping.

Do not point a bright projector directly at anyone's eyes.

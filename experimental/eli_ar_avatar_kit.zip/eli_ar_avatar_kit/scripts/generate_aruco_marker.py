#!/usr/bin/env python3
"""
Generate an ArUco marker PNG for tracking/anchoring the ELI AR overlay.

Print the marker, place it on a wall/desk/surface, then run:
  python scripts/ar_mirror.py --use-marker --asset assets/eli_avatar.png
  python scripts/ar_projector_cast.py --use-marker --mode object-only --asset assets/eli_avatar.png
"""

from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np

ARUCO_DICTS = {
    "4x4_50": cv2.aruco.DICT_4X4_50,
    "4x4_100": cv2.aruco.DICT_4X4_100,
    "5x5_100": cv2.aruco.DICT_5X5_100,
    "6x6_250": cv2.aruco.DICT_6X6_250,
}


def main() -> None:
    p = argparse.ArgumentParser(description="Generate printable ArUco marker PNG.")
    p.add_argument("--id", type=int, default=23)
    p.add_argument("--dict", choices=sorted(ARUCO_DICTS), default="6x6_250")
    p.add_argument("--size", type=int, default=900)
    p.add_argument("--border", type=int, default=80)
    p.add_argument("--out", default="assets/aruco_6x6_250_id23.png")
    args = p.parse_args()

    dictionary = cv2.aruco.getPredefinedDictionary(ARUCO_DICTS[args.dict])

    # API compatibility across OpenCV 4.x builds.
    if hasattr(cv2.aruco, "generateImageMarker"):
        marker = cv2.aruco.generateImageMarker(dictionary, args.id, args.size)
    else:
        marker = np.zeros((args.size, args.size), dtype=np.uint8)
        cv2.aruco.drawMarker(dictionary, args.id, args.size, marker, 1)

    canvas_size = args.size + args.border * 2
    canvas = np.full((canvas_size, canvas_size), 255, dtype=np.uint8)
    canvas[args.border:args.border + args.size, args.border:args.border + args.size] = marker

    label = f"DICT {args.dict} | ID {args.id}"
    cv2.putText(canvas, label, (args.border, canvas_size - 25), cv2.FONT_HERSHEY_SIMPLEX, 1.0, 0, 2, cv2.LINE_AA)

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out), canvas)
    print(f"[+] Wrote {out}")
    print("[+] Print it flat. Glossy paper can reduce tracking reliability; matte paper is better.")


if __name__ == "__main__":
    main()

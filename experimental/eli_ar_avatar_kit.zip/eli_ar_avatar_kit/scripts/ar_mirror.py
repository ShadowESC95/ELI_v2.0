#!/usr/bin/env python3
"""
Software AR Mirror
------------------
Captures a webcam feed, overlays a digital object/avatar, and displays the
augmented feed on the monitor. Optional ArUco marker mode anchors the object
onto a printed marker.

Controls:
  q / ESC       quit
  s             save screenshot
  h             toggle HUD
  m             toggle mirror view
  a             toggle ArUco anchoring
  [ / ]         decrease/increase opacity
  - / =         decrease/increase scale
  arrow keys    move overlay when not marker-anchored

Examples:
  python scripts/ar_mirror.py --camera 0 --asset assets/eli_avatar.png
  python scripts/ar_mirror.py --camera 0 --asset assets/eli_avatar.png --use-marker
"""

from __future__ import annotations

import argparse
import math
import time
from pathlib import Path
from typing import Optional, Tuple

import cv2
import numpy as np


ARUCO_DICTS = {
    "4x4_50": cv2.aruco.DICT_4X4_50,
    "4x4_100": cv2.aruco.DICT_4X4_100,
    "5x5_100": cv2.aruco.DICT_5X5_100,
    "6x6_250": cv2.aruco.DICT_6X6_250,
}


def load_rgba(path: Optional[str], fallback_size: int = 512) -> np.ndarray:
    if path:
        img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
        if img is not None:
            if img.ndim == 2:
                img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGRA)
            if img.shape[2] == 3:
                b, g, r = cv2.split(img)
                a = np.full(b.shape, 255, dtype=np.uint8)
                img = cv2.merge((b, g, r, a))
            return img
        print(f"[!] Could not read asset: {path}. Using generated fallback hologram.")

    # Fallback hologram, no asset required.
    s = fallback_size
    img = np.zeros((s, s, 4), dtype=np.uint8)
    center = (s // 2, s // 2)
    for radius, alpha in [(230, 80), (180, 110), (120, 170), (55, 230)]:
        cv2.circle(img, center, radius, (255, 230, 80, alpha), 4, cv2.LINE_AA)
    cv2.line(img, (s // 2, 90), (s // 2, s - 90), (255, 240, 120, 220), 3, cv2.LINE_AA)
    cv2.line(img, (90, s // 2), (s - 90, s // 2), (255, 240, 120, 220), 3, cv2.LINE_AA)
    cv2.putText(img, "ELI", (s // 2 - 95, s // 2 + 28), cv2.FONT_HERSHEY_SIMPLEX, 2.2, (255, 255, 255, 240), 5, cv2.LINE_AA)
    return img


def overlay_rgba(frame: np.ndarray, asset: np.ndarray, x: int, y: int, scale: float, opacity: float) -> np.ndarray:
    h, w = frame.shape[:2]
    ah, aw = asset.shape[:2]
    nw = max(1, int(aw * scale))
    nh = max(1, int(ah * scale))
    obj = cv2.resize(asset, (nw, nh), interpolation=cv2.INTER_AREA)

    x0 = int(x - nw / 2)
    y0 = int(y - nh / 2)
    x1 = x0 + nw
    y1 = y0 + nh

    # Clip to frame.
    sx0 = max(0, -x0)
    sy0 = max(0, -y0)
    sx1 = nw - max(0, x1 - w)
    sy1 = nh - max(0, y1 - h)
    dx0 = max(0, x0)
    dy0 = max(0, y0)
    dx1 = min(w, x1)
    dy1 = min(h, y1)
    if sx1 <= sx0 or sy1 <= sy0:
        return frame

    crop = obj[sy0:sy1, sx0:sx1]
    alpha = (crop[:, :, 3].astype(np.float32) / 255.0) * opacity
    alpha = alpha[:, :, None]
    frame_roi = frame[dy0:dy1, dx0:dx1].astype(np.float32)
    obj_rgb = crop[:, :, :3].astype(np.float32)
    blended = obj_rgb * alpha + frame_roi * (1.0 - alpha)
    frame[dy0:dy1, dx0:dx1] = blended.astype(np.uint8)
    return frame


def overlay_perspective(frame: np.ndarray, asset: np.ndarray, dst_quad: np.ndarray, opacity: float) -> np.ndarray:
    ah, aw = asset.shape[:2]
    src = np.array([[0, 0], [aw - 1, 0], [aw - 1, ah - 1], [0, ah - 1]], dtype=np.float32)
    dst = dst_quad.astype(np.float32)

    mat = cv2.getPerspectiveTransform(src, dst)
    warped = cv2.warpPerspective(asset, mat, (frame.shape[1], frame.shape[0]), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_TRANSPARENT)
    alpha = (warped[:, :, 3].astype(np.float32) / 255.0) * opacity
    alpha3 = alpha[:, :, None]
    frame_float = frame.astype(np.float32)
    obj_float = warped[:, :, :3].astype(np.float32)
    frame[:] = (obj_float * alpha3 + frame_float * (1.0 - alpha3)).astype(np.uint8)
    return frame


def get_aruco_detector(dict_name: str):
    dictionary = cv2.aruco.getPredefinedDictionary(ARUCO_DICTS[dict_name])
    if hasattr(cv2.aruco, "ArucoDetector"):
        params = cv2.aruco.DetectorParameters()
        return cv2.aruco.ArucoDetector(dictionary, params)
    params = cv2.aruco.DetectorParameters_create()
    return dictionary, params


def detect_markers(gray: np.ndarray, detector):
    if hasattr(cv2.aruco, "ArucoDetector") and not isinstance(detector, tuple):
        return detector.detectMarkers(gray)
    dictionary, params = detector
    return cv2.aruco.detectMarkers(gray, dictionary, parameters=params)


def marker_quad(corners: np.ndarray, lift: float = 0.65, expand: float = 1.05) -> np.ndarray:
    # ArUco corner order: top-left, top-right, bottom-right, bottom-left.
    q = corners.reshape(4, 2).astype(np.float32)
    center = q.mean(axis=0)
    expanded = center + (q - center) * expand
    vertical = ((q[3] + q[2]) / 2) - ((q[0] + q[1]) / 2)
    up = -vertical * lift
    # Raise the top edge so the asset appears to stand above the marker plane.
    dst = expanded.copy()
    dst[0] += up
    dst[1] += up
    return dst


def draw_hud(frame: np.ndarray, fps: float, args: argparse.Namespace, use_marker: bool, opacity: float, scale: float, locked: bool):
    lines = [
        f"ELI AR Mirror | FPS {fps:.1f}",
        f"asset={args.asset or 'generated'} | marker={'on' if use_marker else 'off'} | locked={'yes' if locked else 'no'}",
        f"opacity={opacity:.2f} scale={scale:.2f} | q quit | h HUD | a marker | m mirror | s screenshot",
    ]
    y = 28
    for line in lines:
        cv2.putText(frame, line, (16, y), cv2.FONT_HERSHEY_SIMPLEX, 0.62, (0, 0, 0), 4, cv2.LINE_AA)
        cv2.putText(frame, line, (16, y), cv2.FONT_HERSHEY_SIMPLEX, 0.62, (255, 255, 255), 1, cv2.LINE_AA)
        y += 27


def main() -> None:
    p = argparse.ArgumentParser(description="Software AR mirror using webcam + OpenCV.")
    p.add_argument("--camera", type=int, default=0)
    p.add_argument("--asset", default="assets/eli_avatar.png")
    p.add_argument("--width", type=int, default=1280)
    p.add_argument("--height", type=int, default=720)
    p.add_argument("--fps", type=int, default=30)
    p.add_argument("--mirror", action="store_true", default=True)
    p.add_argument("--no-mirror", dest="mirror", action="store_false")
    p.add_argument("--use-marker", action="store_true")
    p.add_argument("--aruco-dict", choices=sorted(ARUCO_DICTS), default="6x6_250")
    p.add_argument("--marker-lift", type=float, default=0.65)
    p.add_argument("--opacity", type=float, default=0.82)
    p.add_argument("--scale", type=float, default=0.38)
    p.add_argument("--window", default="ELI Software AR Mirror")
    args = p.parse_args()

    cap = cv2.VideoCapture(args.camera)
    if not cap.isOpened():
        raise SystemExit(f"[-] Could not open webcam index {args.camera}")
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.height)
    cap.set(cv2.CAP_PROP_FPS, args.fps)

    asset = load_rgba(args.asset)
    detector = get_aruco_detector(args.aruco_dict)

    cv2.namedWindow(args.window, cv2.WINDOW_NORMAL)
    x, y = args.width // 2, args.height // 2
    opacity = max(0.0, min(1.0, args.opacity))
    scale = max(0.05, args.scale)
    use_marker = args.use_marker
    show_hud = True
    mirror = args.mirror
    last = time.time()
    fps_smooth = 0.0

    while True:
        ok, frame = cap.read()
        if not ok:
            print("[!] Empty camera frame")
            continue
        if mirror:
            frame = cv2.flip(frame, 1)

        locked = False
        if use_marker:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            corners, ids, rejected = detect_markers(gray, detector)
            if ids is not None and len(corners) > 0:
                # Choose the largest visible marker for stability.
                areas = [cv2.contourArea(c.reshape(4, 2).astype(np.float32)) for c in corners]
                idx = int(np.argmax(areas))
                dst = marker_quad(corners[idx], lift=args.marker_lift)
                frame = overlay_perspective(frame, asset, dst, opacity)
                cv2.aruco.drawDetectedMarkers(frame, [corners[idx]], ids[idx:idx + 1])
                locked = True

        if not locked:
            frame = overlay_rgba(frame, asset, x, y, scale, opacity)

        now = time.time()
        dt = max(1e-6, now - last)
        fps_now = 1.0 / dt
        fps_smooth = fps_now if fps_smooth == 0 else fps_smooth * 0.9 + fps_now * 0.1
        last = now

        if show_hud:
            draw_hud(frame, fps_smooth, args, use_marker, opacity, scale, locked)

        cv2.imshow(args.window, frame)
        key = cv2.waitKey(1) & 0xFF
        if key in (ord("q"), 27):
            break
        elif key == ord("h"):
            show_hud = not show_hud
        elif key == ord("m"):
            mirror = not mirror
        elif key == ord("a"):
            use_marker = not use_marker
        elif key == ord("s"):
            out = Path(f"eli_ar_mirror_{int(time.time())}.png")
            cv2.imwrite(str(out), frame)
            print(f"[+] Saved {out}")
        elif key == ord("["):
            opacity = max(0.05, opacity - 0.05)
        elif key == ord("]"):
            opacity = min(1.0, opacity + 0.05)
        elif key in (ord("-"), ord("_")):
            scale = max(0.05, scale - 0.03)
        elif key in (ord("="), ord("+")):
            scale = min(2.0, scale + 0.03)
        elif key == 81:  # left arrow, Linux/X11 common
            x -= 15
        elif key == 83:  # right arrow
            x += 15
        elif key == 82:  # up arrow
            y -= 15
        elif key == 84:  # down arrow
            y += 15

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()

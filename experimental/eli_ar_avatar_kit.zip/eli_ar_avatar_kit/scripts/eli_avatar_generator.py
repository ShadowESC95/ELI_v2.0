#!/usr/bin/env python3
"""
ELI Avatar Generator
--------------------
Creates a reusable avatar image for ELI.

Backends:
  procedural  : fully offline, deterministic, no AI model required.
  diffusers   : optional local Stable Diffusion/Diffusers backend.

Examples:
  python scripts/eli_avatar_generator.py --backend procedural --out assets/eli_avatar.png
  python scripts/eli_avatar_generator.py --backend diffusers --model ./models/sd15 --prompt "..." --out assets/eli_avatar.png
"""

from __future__ import annotations

import argparse
import json
import math
import os
import random
from pathlib import Path
from typing import Tuple

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont


def _font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf",
    ]
    for path in candidates:
        if os.path.exists(path):
            return ImageFont.truetype(path, size=size)
    return ImageFont.load_default()


def _radial_background(size: int, seed: int) -> Image.Image:
    rng = random.Random(seed)
    arr = np.zeros((size, size, 4), dtype=np.uint8)
    cx, cy = size / 2, size / 2
    max_r = math.sqrt(cx * cx + cy * cy)
    tint_shift = rng.randint(-12, 12)
    for y in range(size):
        for x in range(size):
            dx = x - cx
            dy = y - cy
            r = math.sqrt(dx * dx + dy * dy) / max_r
            angle = math.atan2(dy, dx)
            wave = 0.5 + 0.5 * math.sin(8 * angle + 20 * r)
            base = int(18 + 58 * (1 - r) + 18 * wave)
            arr[y, x] = [max(0, base - 8), max(0, base + tint_shift), min(255, base + 45), 255]
    return Image.fromarray(arr, "RGBA").filter(ImageFilter.GaussianBlur(0.6))


def _draw_glow_line(draw: ImageDraw.ImageDraw, pts, color, width: int):
    for w, alpha in [(width + 14, 35), (width + 8, 55), (width + 3, 90), (width, color[3])]:
        c = (color[0], color[1], color[2], alpha)
        draw.line(pts, fill=c, width=w, joint="curve")


def procedural_avatar(
    output: Path,
    size: int = 1024,
    seed: int = 95,
    label: str = "ELI",
    subtitle: str = "LOCAL-FIRST INTELLIGENCE",
) -> None:
    rng = random.Random(seed)
    img = _radial_background(size, seed)

    # Work on a transparent overlay for glow/effects.
    fx = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(fx)
    c = size // 2

    # Outer rings.
    for i, radius in enumerate([430, 375, 310, 245, 170]):
        alpha = 70 + i * 18
        width = max(2, 8 - i)
        bbox = (c - radius, c - radius, c + radius, c + radius)
        draw.ellipse(bbox, outline=(90, 230, 255, alpha), width=width)

    # Rotated circuit polygons.
    for ring, radius in enumerate([395, 330, 270]):
        points = []
        sides = 12 + ring * 4
        offset = rng.random() * math.tau
        for k in range(sides):
            a = offset + k * math.tau / sides
            rr = radius + rng.randint(-18, 18)
            points.append((c + rr * math.cos(a), c + rr * math.sin(a)))
        for k in range(len(points)):
            if k % 2 == 0:
                _draw_glow_line(draw, [points[k], points[(k + 1) % len(points)]], (70, 210, 255, 120), 3)

    # Central face plate.
    plate_r = 235
    draw.ellipse((c - plate_r, c - plate_r, c + plate_r, c + plate_r), fill=(8, 17, 25, 220), outline=(150, 240, 255, 220), width=7)
    draw.ellipse((c - 188, c - 188, c + 188, c + 188), outline=(70, 210, 255, 145), width=3)

    # Eyes / interface nodes.
    eye_y = c - 45
    for ex in [c - 85, c + 85]:
        draw.rounded_rectangle((ex - 50, eye_y - 23, ex + 50, eye_y + 23), radius=18, fill=(70, 230, 255, 210))
        draw.rounded_rectangle((ex - 36, eye_y - 10, ex + 36, eye_y + 10), radius=9, fill=(235, 255, 255, 235))

    # Neural bridge / mouth waveform.
    wave_pts = []
    for i in range(180):
        x = c - 120 + i * (240 / 179)
        y = c + 85 + 16 * math.sin(i / 12) + 6 * math.sin(i / 3.7)
        wave_pts.append((x, y))
    _draw_glow_line(draw, wave_pts, (110, 245, 255, 210), 4)

    # Node constellations.
    for _ in range(80):
        a = rng.random() * math.tau
        r = rng.randint(190, 430)
        x = c + int(r * math.cos(a))
        y = c + int(r * math.sin(a))
        if 0 <= x < size and 0 <= y < size:
            rad = rng.choice([2, 3, 4])
            draw.ellipse((x - rad, y - rad, x + rad, y + rad), fill=(160, 245, 255, rng.randint(100, 210)))

    # Text.
    title_font = _font(size // 8)
    sub_font = _font(size // 34)
    title_box = draw.textbbox((0, 0), label, font=title_font)
    title_w = title_box[2] - title_box[0]
    title_pos = (c - title_w // 2, c + 245)
    draw.text((title_pos[0] + 3, title_pos[1] + 3), label, font=title_font, fill=(0, 0, 0, 160))
    draw.text(title_pos, label, font=title_font, fill=(235, 255, 255, 245))

    sub_box = draw.textbbox((0, 0), subtitle, font=sub_font)
    sub_w = sub_box[2] - sub_box[0]
    sub_pos = (c - sub_w // 2, c + 365)
    draw.text(sub_pos, subtitle, font=sub_font, fill=(150, 235, 255, 210))

    # Soft bloom.
    bloom = fx.filter(ImageFilter.GaussianBlur(8))
    img = Image.alpha_composite(img, bloom)
    img = Image.alpha_composite(img, fx)

    output.parent.mkdir(parents=True, exist_ok=True)
    img.save(output)

    meta = {
        "name": label,
        "backend": "procedural",
        "size": size,
        "seed": seed,
        "file": str(output),
        "intended_use": "ELI GUI avatar and AR overlay asset",
    }
    output.with_suffix(".json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(f"[+] Wrote {output}")
    print(f"[+] Wrote {output.with_suffix('.json')}")


def diffusion_avatar(args: argparse.Namespace) -> None:
    try:
        import torch
        from diffusers import DiffusionPipeline
    except Exception as exc:
        raise SystemExit(
            "[-] Diffusers backend missing. Install optional deps first:\n"
            "    python -m pip install -r requirements_diffusion.txt\n"
            f"    Import error: {exc}"
        )

    model = args.model
    if not model:
        raise SystemExit("[-] --model is required for --backend diffusers. Use a local model folder for offline use.")

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    dtype = torch.float16 if torch.cuda.is_available() else torch.float32
    pipe = DiffusionPipeline.from_pretrained(
        model,
        torch_dtype=dtype,
        local_files_only=not args.online_ok,
        safety_checker=None if args.disable_safety_checker else None,
    )
    if torch.cuda.is_available():
        pipe = pipe.to("cuda")
        try:
            pipe.enable_attention_slicing()
        except Exception:
            pass

    generator = torch.Generator(device="cuda" if torch.cuda.is_available() else "cpu").manual_seed(args.seed)
    image = pipe(
        prompt=args.prompt,
        negative_prompt=args.negative_prompt,
        num_inference_steps=args.steps,
        guidance_scale=args.guidance,
        generator=generator,
        width=args.size,
        height=args.size,
    ).images[0]
    image.save(out)
    out.with_suffix(".json").write_text(
        json.dumps(
            {
                "backend": "diffusers",
                "model": model,
                "prompt": args.prompt,
                "negative_prompt": args.negative_prompt,
                "seed": args.seed,
                "steps": args.steps,
                "guidance": args.guidance,
                "file": str(out),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"[+] Wrote {out}")


def parse_args() -> argparse.Namespace:
    default_prompt = (
        "ELI, a dark futuristic local-first AI assistant avatar, circular holographic interface, "
        "cyan neural circuitry, sharp intelligent eyes, high contrast, clean vector-like design, "
        "no text, no watermark, centered, black background"
    )
    p = argparse.ArgumentParser(description="Generate an ELI avatar image.")
    p.add_argument("--backend", choices=["procedural", "diffusers"], default="procedural")
    p.add_argument("--out", default="assets/eli_avatar.png")
    p.add_argument("--size", type=int, default=1024)
    p.add_argument("--seed", type=int, default=95)
    p.add_argument("--label", default="ELI")
    p.add_argument("--subtitle", default="LOCAL-FIRST INTELLIGENCE")
    p.add_argument("--model", default="", help="Local Diffusers model folder or repo id if --online-ok is used.")
    p.add_argument("--prompt", default=default_prompt)
    p.add_argument("--negative-prompt", default="blurry, low quality, text, watermark, distorted face, extra limbs")
    p.add_argument("--steps", type=int, default=28)
    p.add_argument("--guidance", type=float, default=7.0)
    p.add_argument("--online-ok", action="store_true", help="Allow model download. Leave off for offline/local-only use.")
    p.add_argument("--disable-safety-checker", action="store_true", help="Compatibility flag; kept explicit for local research setups.")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    if args.backend == "procedural":
        procedural_avatar(Path(args.out), args.size, args.seed, args.label, args.subtitle)
    else:
        diffusion_avatar(args)


if __name__ == "__main__":
    main()

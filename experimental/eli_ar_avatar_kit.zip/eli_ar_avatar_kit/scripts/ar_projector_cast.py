#!/usr/bin/env python3
"""
Hardware Extension: Projector AR Cast
-------------------------------------
Uses a webcam feed, overlays AR content, and displays the result full-screen
on a second monitor/projector.

Modes:
  composite    projector shows webcam video + AR object
  object-only  projector shows only the AR object on black background

For actual physical projection onto surfaces, object-only mode is usually more
useful than projecting the full camera feed. Composite mode is useful for demoing
an AR mirror on a large display.

Controls:
  q / ESC       quit
  s             save screenshot
  h             toggle HUD
  m             toggle mirror
  a             toggle ArUco anchoring
  c             toggle composite/object-only
  [ / ]         opacity
  - / =         scale
  arrow keys    move object when not marker-anchored

Examples:
  xrandr --listmonitors
  python scripts/ar_projector_cast.py --camera 0 --asset assets/eli_avatar.png --screen-x 1920 --screen-y 0 --fullscreen
  python scripts/ar_projector_cast.py --mode object-only --use-marker --screen-x 1920 --screen-y 0 --fullscreen
"""

from __future__ import annotations

import argparse
import time
from pathlib import Path

import cv2
import numpy as np

from ar_mirror import (
    ARUCO_DICTS,
    detect_markers,
    draw_hud,
    get_aruco_detector,
    load_rgba,
    marker_quad,
    overlay_perspective,
    overlay_rgba,
)


def main() -> None:
    p = argparse.ArgumentParser(description="Project webcam AR feed full-screen onto a second monitor/projector.")
    p.add_argument("--camera", type=int, default=0)
    p.add_argument("--asset", default="assets/eli_avatar.png")
    p.add_argument("--width", type=int, default=1280, help="Capture/output width.")
    p.add_argument("--height", type=int, default=720, help="Capture/output height.")
    p.add_argument("--fps", type=int, default=30)
    p.add_argument("--mode", choices=["composite", "object-only"], default="object-only")
    p.add_argument("--screen-x", type=int, default=0, help="Projector monitor X offset from xrandr.")
    p.add_argument("--screen-y", type=int, default=0, help="Projector monitor Y offset from xrandr.")
    p.add_argument("--fullscreen", action="store_true")
    p.add_argument("--mirror", action="store_true", default=False)
    p.add_argument("--use-marker", action="store_true")
    p.add_argument("--aruco-dict", choices=sorted(ARUCO_DICTS), default="6x6_250")
    p.add_argument("--marker-lift", type=float, default=0.65)
    p.add_argument("--opacity", type=float, default=0.92)
    p.add_argument("--scale", type=float, default=0.42)
    p.add_argument("--window", default="ELI Projector AR Cast")
    args = p.parse_args()

    cap = cv2.VideoCapture(args.camera)
    if not cap.isOpened():
        raise SystemExit(f"[-] Could not open webcam index {args.camera}")
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.height)
    cap.set(cv2.CAP_PROP_FPS, args.fps)

    asset = load_rgba(args.asset)
    detector = get_aruco_detector(args.aruco_dict)

    cv2.namedWindow(args.window, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(args.window, args.width, args.height)
    cv2.moveWindow(args.window, args.screen_x, args.screen_y)
    if args.fullscreen:
        cv2.setWindowProperty(args.window, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

    x, y = args.width // 2, args.height // 2
    opacity = max(0.0, min(1.0, args.opacity))
    scale = max(0.05, args.scale)
    use_marker = args.use_marker
    show_hud = True
    mirror = args.mirror
    mode = args.mode
    last = time.time()
    fps_smooth = 0.0

    print("[+] Projector AR started")
    print("[+] Use xrandr --listmonitors to get projector offset; pass it with --screen-x/--screen-y")
    print("[+] Press q or ESC to quit")

    while True:
        ok, camera_frame = cap.read()
        if not ok:
            print("[!] Empty camera frame")
            continue
        camera_frame = cv2.resize(camera_frame, (args.width, args.height), interpolation=cv2.INTER_AREA)
        if mirror:
            camera_frame = cv2.flip(camera_frame, 1)

        if mode == "composite":
            frame = camera_frame.copy()
        else:
            frame = np.zeros_like(camera_frame)

        locked = False
        if use_marker:
            # Detect marker in the real camera feed, but draw onto the chosen output frame.
            gray = cv2.cvtColor(camera_frame, cv2.COLOR_BGR2GRAY)
            corners, ids, rejected = detect_markers(gray, detector)
            if ids is not None and len(corners) > 0:
                areas = [cv2.contourArea(c.reshape(4, 2).astype(np.float32)) for c in corners]
                idx = int(np.argmax(areas))
                dst = marker_quad(corners[idx], lift=args.marker_lift)
                frame = overlay_perspective(frame, asset, dst, opacity)
                if mode == "composite":
                    cv2.aruco.drawDetectedMarkers(frame, [corners[idx]], ids[idx:idx + 1])
                locked = True

        if not locked:
            frame = overlay_rgba(frame, asset, x, y, scale, opacity)

        now = time.time()
        dt = max(1e-6, now - last)
        fps_now = 1.0 / dt
        fps_smooth = fps_now if fps_smooth == 0 else fps_smooth * 0.9 + fps_now * 0.1
        last = now

        if show_hud and mode == "composite":
            draw_hud(frame, fps_smooth, args, use_marker, opacity, scale, locked)
        elif show_hud and mode == "object-only":
            txt = f"ELI Projector | {mode} | FPS {fps_smooth:.1f} | q quit | c mode | a marker | h HUD"
            cv2.putText(frame, txt, (20, 38), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2, cv2.LINE_AA)

        cv2.imshow(args.window, frame)
        key = cv2.waitKey(1) & 0xFF
        if key in (ord("q"), 27):
            break
        elif key == ord("h"):
            show_hud = not show_hud
        elif key == ord("m"):
            mirror = not mirror
        elif key == ord("a"):
            use_marker = not use_marker
        elif key == ord("c"):
            mode = "composite" if mode == "object-only" else "object-only"
        elif key == ord("s"):
            out = Path(f"eli_projector_cast_{int(time.time())}.png")
            cv2.imwrite(str(out), frame)
            print(f"[+] Saved {out}")
        elif key == ord("["):
            opacity = max(0.05, opacity - 0.05)
        elif key == ord("]"):
            opacity = min(1.0, opacity + 0.05)
        elif key in (ord("-"), ord("_")):
            scale = max(0.05, scale - 0.03)
        elif key in (ord("="), ord("+")):
            scale = min(2.0, scale + 0.03)
        elif key == 81:
            x -= 15
        elif key == 83:
            x += 15
        elif key == 82:
            y -= 15
        elif key == 84:
            y += 15

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()

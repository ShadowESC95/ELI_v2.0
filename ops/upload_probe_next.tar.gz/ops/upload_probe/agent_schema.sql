CREATE TABLE capability_proposals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts REAL,
            timestamp REAL,
            proposed_name TEXT,
            capability TEXT,
            description TEXT,
            examples TEXT,
            plugin_code TEXT,
            reasoning TEXT,
            rationale TEXT,
            status TEXT DEFAULT 'pending',
            priority TEXT,
            notes TEXT,
            created_at REAL,
            updated_at REAL,
            source TEXT,
            category TEXT
        );
CREATE TABLE sqlite_sequence(name,seq);
CREATE TABLE conversation_turns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            user_id TEXT,
            role TEXT,
            content TEXT,
            ts REAL,
            timestamp REAL
        );
CREATE TABLE conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            user_id TEXT,
            role TEXT,
            content TEXT,
            timestamp REAL,
            ts REAL,
            created_at REAL,
            updated_at REAL,
            title TEXT
        );
CREATE TABLE corrections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original TEXT,
            corrected TEXT,
            timestamp REAL,
            ts REAL
        );
CREATE TABLE error_tracking (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            error_type TEXT,
            details TEXT,
            timestamp REAL,
            occurrence_count INTEGER DEFAULT 1,
            first_seen REAL,
            last_seen REAL
        );
CREATE TABLE failures (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts REAL,
            timestamp REAL,
            user_input TEXT,
            command TEXT,
            error TEXT,
            traceback TEXT,
            confidence REAL,
            low_confidence INTEGER DEFAULT 0,
            context TEXT,
            context_json TEXT,
            occurrence_count INTEGER DEFAULT 1,
            first_seen REAL,
            last_seen REAL,
            failure TEXT,
            name TEXT,
            text TEXT,
            content TEXT,
            details TEXT,
            description TEXT,
            source TEXT,
            signature TEXT,
            status TEXT,
            count INTEGER DEFAULT 1
        );
CREATE TABLE habit_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT,
            event TEXT,
            details TEXT,
            data TEXT,
            timestamp REAL,
            ts REAL,
            name TEXT,
            cmd TEXT,
            method TEXT,
            command TEXT
        );
CREATE TABLE habit_rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            command TEXT,
            hour INTEGER,
            minute INTEGER,
            days TEXT,
            enabled INTEGER DEFAULT 1,
            timestamp REAL,
            ts REAL,
            pattern TEXT,
            action TEXT,
            trigger_phrase TEXT,
            action_type TEXT
        );
CREATE TABLE habits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            cmd TEXT,
            method TEXT,
            count INTEGER DEFAULT 0,
            hour INTEGER,
            minute INTEGER,
            timestamp REAL,
            command TEXT,
            enabled INTEGER DEFAULT 1,
            ts REAL
        );
CREATE TABLE improvements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts REAL,
            timestamp REAL,
            category TEXT,
            area TEXT,
            description TEXT,
            priority INTEGER DEFAULT 1,
            status TEXT DEFAULT 'pending',
            created_at REAL,
            title TEXT,
            name TEXT,
            improvement TEXT,
            text TEXT,
            content TEXT,
            details TEXT,
            source TEXT,
            count INTEGER DEFAULT 1,
            suggestion TEXT,
            applied INTEGER DEFAULT 0
        );
CREATE TABLE memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT,
            value TEXT,
            content TEXT,
            tags TEXT,
            kind TEXT,
            ts REAL,
            timestamp REAL,
            source TEXT,
            status TEXT,
            weight REAL DEFAULT 1.0,
            confidence REAL DEFAULT 1.0
        , importance REAL DEFAULT 0.5);
CREATE VIRTUAL TABLE memories_fts USING fts5(
    text,
    content,
    tags,
    source,
    kind,
    content='memories',
    content_rowid='id',
    tokenize='unicode61'
)
/* memories_fts(text,content,tags,source,kind) */;
CREATE TABLE IF NOT EXISTS 'memories_fts_data'(id INTEGER PRIMARY KEY, block BLOB);
CREATE TABLE IF NOT EXISTS 'memories_fts_idx'(segid, term, pgno, PRIMARY KEY(segid, term)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS 'memories_fts_docsize'(id INTEGER PRIMARY KEY, sz BLOB);
CREATE TABLE IF NOT EXISTS 'memories_fts_config'(k PRIMARY KEY, v) WITHOUT ROWID;
CREATE TABLE observations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT,
            category TEXT,
            observation TEXT,
            content TEXT,
            text TEXT,
            details TEXT,
            timestamp REAL,
            ts REAL
        );
CREATE TABLE observations_archive (
            archive_id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_id INTEGER UNIQUE,
            source TEXT,
            category TEXT,
            observation TEXT,
            content TEXT,
            text TEXT,
            details TEXT,
            timestamp REAL,
            ts REAL,
            archived_at REAL,
            archive_reason TEXT
        );
CREATE TABLE recall_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts REAL,
            timestamp REAL,
            query TEXT,
            results_count INTEGER,
            result_count INTEGER,
            memory_id INTEGER
        );
CREATE TABLE session_summaries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            user_id TEXT,
            summary TEXT,
            turns_count INTEGER,
            started_at REAL,
            ended_at REAL,
            source TEXT,
            timestamp REAL,
            ts REAL
        );
CREATE TABLE user_patterns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            pattern_type TEXT,
            pattern_data TEXT,
            timestamp REAL,
            ts REAL
        );
CREATE TRIGGER memories_ad AFTER DELETE ON memories BEGIN
  INSERT INTO memories_fts(memories_fts, rowid, text, content, tags, source, kind)
  VALUES(
    'delete',
    old.id,
    COALESCE(old.text,''),
    COALESCE(old.content,''),
    COALESCE(old.tags,''),
    COALESCE(old.source,''),
    COALESCE(old.kind,'')
  );
END;
CREATE TRIGGER memories_ai AFTER INSERT ON memories BEGIN
  INSERT INTO memories_fts(rowid, text, content, tags, source, kind)
  VALUES(
    new.id,
    COALESCE(new.text,''),
    COALESCE(new.content,''),
    COALESCE(new.tags,''),
    COALESCE(new.source,''),
    COALESCE(new.kind,'')
  );
END;
CREATE TRIGGER memories_au AFTER UPDATE ON memories BEGIN
  INSERT INTO memories_fts(memories_fts, rowid, text, content, tags, source, kind)
  VALUES(
    'delete',
    old.id,
    COALESCE(old.text,''),
    COALESCE(old.content,''),
    COALESCE(old.tags,''),
    COALESCE(old.source,''),
    COALESCE(old.kind,'')
  );
  INSERT INTO memories_fts(rowid, text, content, tags, source, kind)
  VALUES(
    new.id,
    COALESCE(new.text,''),
    COALESCE(new.content,''),
    COALESCE(new.tags,''),
    COALESCE(new.source,''),
    COALESCE(new.kind,'')
  );
END;
CREATE TRIGGER observations_ignore_duplicate_proactive_started
        BEFORE INSERT ON observations
        WHEN lower(trim(coalesce(NEW.observation, NEW.content, NEW.text, NEW.details, ''))) = 'proactive daemon started'
         AND EXISTS (
            SELECT 1
            FROM observations
            WHERE lower(trim(coalesce(observation, content, text, details, ''))) = 'proactive daemon started'
         )
        BEGIN
            SELECT RAISE(IGNORE);
        END;

from __future__ import annotations

import re
from typing import Any


def _norm(text: Any) -> str:
    return re.sub(r"\s+", " ", str(text or "").lower()).strip()


def _is_remember_preference(text: Any) -> bool:
    low = _norm(text)

    rememberish = (
        low.startswith("remember ")
        or low.startswith("remember:")
        or low.startswith("remember moving forward")
        or low.startswith("note ")
        or low.startswith("note:")
        or low.startswith("from now on")
        or low.startswith("moving forward")
    )

    preferenceish = any(
        marker in low
        for marker in (
            "i prefer",
            "my preference",
            "no vague descriptions",
            "direct bash commands",
            "full diagnostics",
            "full diagnostic",
            "step-by-step",
            "in depth",
            "in-depth",
            "bullshit-free",
            "challenge my assumptions",
        )
    )

    return bool(rememberish and preferenceish)


def _extract_corrected_target(text: Any) -> str:
    raw = str(text or "").strip()
    if not raw:
        return ""

    patterns = (
        r'i\s+did\s+not\s+ask\s+[^.?!]*?\bi\s+asked\s+you\s+[\"“](.*?)[\"”]',
        r'i\s+asked\s+you\s+[\"“](.*?)[\"”]',
    )

    for pat in patterns:
        m = re.search(pat, raw, flags=re.I | re.S)
        if m:
            target = re.sub(r"\s+", " ", m.group(1)).strip()
            if 1 <= len(target) <= 240:
                return target

    return ""



def _clean_memory_runtime_answer(result: Any) -> Any:
    """
    Final governance for EXPLAIN_MEMORY_RUNTIME.

    This does not replace the grounded cognitive path.
    It only removes synthesis artefacts that should never appear in the final
    answer: identity intro, private underscore helpers/classes, and rough comma
    damage caused by removing those private names.
    """
    if not isinstance(result, dict):
        return result

    meta = result.get("meta") if isinstance(result.get("meta"), dict) else {}
    action = str(
        result.get("action")
        or meta.get("grounded_action")
        or meta.get("action")
        or ""
    ).strip().upper()

    if action != "EXPLAIN_MEMORY_RUNTIME":
        return result

    def clean(text: Any) -> str:
        t = str(text or "").strip()
        if not t:
            return t

        # Remove identity/self-introduction fluff. This answer should start
        # with the memory system, not with "I am ELI".
        t = re.sub(
            r"^\s*(?:I am|I'm)\s+ELI,\s+(?:a\s+)?(?:local\s+)?(?:GGUF[- ]powered\s+)?assistant/runtime\.?\s*",
            "",
            t,
            flags=re.I,
        )
        t = re.sub(
            r"^\s*(?:I am|I'm)\s+ELI,\s+[^.]{0,220}\.\s*",
            "",
            t,
            flags=re.I,
        )

        # Prefer neutral technical opening.
        t = re.sub(r"^\s*My memory system\b", "The memory system", t, flags=re.I)

        # Remove private/underscore implementation names from final answer.
        # Examples removed: _MemoryModule, _MemoryMeta, _connect, _cols, etc.
        t = re.sub(r"\b_[A-Za-z][A-Za-z0-9_]*\b,?\s*", "", t)

        # Clean punctuation damage after removing private identifiers.
        t = re.sub(r",\s*,+", ",", t)
        t = re.sub(r"\(\s*,", "(", t)
        t = re.sub(r"\[\s*,", "[", t)
        t = re.sub(r",\s*\)", ")", t)
        t = re.sub(r",\s*\]", "]", t)
        t = re.sub(r"\bclasses like\s*,", "classes like", t, flags=re.I)
        t = re.sub(r"\bclasses such as\s*,", "classes such as", t, flags=re.I)
        t = re.sub(r"\bclasses like\s+and functions\b", "functions", t, flags=re.I)
        t = re.sub(r"\bclasses such as\s+and functions\b", "functions", t, flags=re.I)
        t = re.sub(r"\bContains classes like\s+functions\b", "Contains functions", t, flags=re.I)
        t = re.sub(r"\bContains classes such as\s+functions\b", "Contains functions", t, flags=re.I)
        t = re.sub(r"\s{2,}", " ", t).strip()

        return t

    for key in ("response", "content"):
        if result.get(key) is not None:
            result[key] = clean(result.get(key))

    if result.get("response") and result.get("content") != result.get("response"):
        result["content"] = result["response"]
    elif result.get("content") and result.get("response") != result.get("content"):
        result["response"] = result["content"]

    result["metadata_fixed_by"] = "phaseBA.memory_runtime_final_sanitiser"
    meta = dict(meta)
    meta["final_sanitiser"] = "phaseBA.memory_runtime_final_sanitiser"
    meta["private_symbol_filter"] = True
    meta["identity_intro_filter"] = True
    result["meta"] = meta

    return result

def _normalise_result_metadata(result: Any) -> Any:
    if not isinstance(result, dict):
        return result

    result = dict(result)

    if "content" not in result and result.get("response") is not None:
        result["content"] = result.get("response")
    if "response" not in result and result.get("content") is not None:
        result["response"] = result.get("content")

    if "confidence_score" not in result and result.get("confidence") is not None:
        try:
            result["confidence_score"] = float(result.get("confidence"))
        except Exception:
            result["confidence_score"] = result.get("confidence")

    meta = result.get("meta") if isinstance(result.get("meta"), dict) else {}
    reasoning = meta.get("reasoning") if isinstance(meta.get("reasoning"), dict) else {}

    if "evidence_used" not in result:
        if "evidence_used" in reasoning:
            result["evidence_used"] = bool(reasoning.get("evidence_used"))
        else:
            result["evidence_used"] = False

    if "grounded" not in result:
        if "grounded" in reasoning:
            result["grounded"] = bool(reasoning.get("grounded"))
        else:
            result["grounded"] = bool(result.get("evidence_used"))

    try:
        result = _clean_memory_runtime_answer(result)
    except Exception:
        pass

    return result


def _run_profile_writer(engine: Any, user_input: Any, result: Any) -> None:
    try:
        from eli.runtime.profile_extractor import after_process_hook

        hook_result = after_process_hook(engine, user_input, result)

        try:
            print(
                "[MEMORY] profile writer: "
                f"patterns={hook_result.get('inserted_patterns')} "
                f"summary_inserted={hook_result.get('summary', {}).get('inserted')}"
            )
        except Exception:
            pass

    except Exception as e:
        try:
            print(f"[MEMORY] profile writer failed: {e}")
        except Exception:
            pass


def install_memory_intercepts(CognitiveEngine: Any) -> bool:
    """
    PhaseAT wrapper.

    This deliberately does NOT return direct runtime/memory/self-report surfaces.

    Runtime, memory, identity, and cognition facts must be used as evidence by
    the normal cognitive pipeline, not substituted as the final answer.
    """
    if getattr(CognitiveEngine, "_memory_intercepts_installed", False):
        return False

    original_process = CognitiveEngine.process

    def _memory_intercepts_process(self, user_input=None, *args, **kwargs):
        text = "" if user_input is None else str(user_input)

        # 1. Explicit memory/preference write. This is an actual write action,
        # not a diagnostic final-answer surface.
        if _is_remember_preference(text):
            try:
                from eli.runtime.profile_extractor import write_patterns_from_turn

                inserted = write_patterns_from_turn(text)
                result = {
                    "ok": True,
                    "action": "MEMORY_STORE",
                    "confidence": 0.96,
                    "confidence_score": 0.96,
                    "evidence_used": True,
                    "grounded": True,
                    "response": (
                        "Memory updated: stored structured user preference signal"
                        + (
                            f" ({inserted} new pattern row(s))."
                            if inserted
                            else " (already present or no new row)."
                        )
                    ),
                    "content": (
                        "Memory updated: stored structured user preference signal"
                        + (
                            f" ({inserted} new pattern row(s))."
                            if inserted
                            else " (already present or no new row)."
                        )
                    ),
                    "meta": {"response_mode": "memory_write"},
                }
                _run_profile_writer(self, user_input, result)
                return result
            except Exception as e:
                try:
                    print(f"[MEMORY] remember/preference intercept failed: {e}")
                except Exception:
                    pass

        # 2. Correction repair. Re-run the corrected target through the normal
        # engine route instead of asking the model to explain the correction.
        target = _extract_corrected_target(text)
        if target:
            try:
                result = original_process(self, target, *args, **kwargs)
                result = _normalise_result_metadata(result)
                if isinstance(result, dict):
                    meta = dict(result.get("meta") or {})
                    meta.update({
                        "speech_act": "CORRECTION_REPAIR",
                        "corrected_target": target,
                        "context_scope": "rerouted_through_normal_engine",
                    })
                    result["meta"] = meta
                _run_profile_writer(self, user_input, result)
                return result
            except Exception as e:
                try:
                    print(f"[MEMORY] correction repair reroute failed: {e}")
                except Exception:
                    pass

        # 3. Normal dynamic cognitive path. No direct grounded surfaces here.
        result = original_process(self, user_input, *args, **kwargs)
        result = _normalise_result_metadata(result)

        # 4. Profile/session writer.
        _run_profile_writer(self, user_input, result)
        return result

    CognitiveEngine.process = _memory_intercepts_process
    CognitiveEngine._memory_intercepts_installed = True
    CognitiveEngine._memory_intercepts_original_process = original_process
    CognitiveEngine._memory_intercepts_phase = "PhaseAT_no_direct_surface_takeover"
    return True

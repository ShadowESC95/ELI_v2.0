from __future__ import annotations

import importlib
import json
import re
import sqlite3
import time
from pathlib import Path
from typing import Any, Dict, List


def _root() -> Path:
    return Path(__file__).resolve().parents[2]


def _artifacts() -> Path:
    return _root() / "artifacts"


def _runtime_dir() -> Path:
    return _artifacts() / "runtime"


def _db_path() -> Path:
    return _artifacts() / "db" / "user.sqlite3"


def _read_json(path: Path) -> Dict[str, Any]:
    try:
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return {}


def runtime_snapshot() -> Dict[str, Any]:
    return _read_json(_artifacts() / "runtime_snapshot.json")


def last_trace() -> Dict[str, Any]:
    return _read_json(_runtime_dir() / "last_trace.json")


def _state_profile() -> tuple[Dict[str, Any], Dict[str, Any]]:
    state = {}
    profile = {}
    try:
        from eli.kernel.state import load_state, load_user_profile
        state = dict(load_state() or {})
        profile = dict(load_user_profile() or {})
    except Exception:
        pass
    return state, profile


def stored_user_name() -> str:
    st, pr = _state_profile()
    return str(st.get("user_name") or pr.get("name") or "").strip()


def _conn() -> sqlite3.Connection | None:
    db = _db_path()
    if not db.exists():
        return None
    try:
        return sqlite3.connect(str(db))
    except Exception:
        return None


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    try:
        row = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
            (table,),
        ).fetchone()
        return bool(row)
    except Exception:
        return False


def _count(conn: sqlite3.Connection, table: str) -> int:
    try:
        if _table_exists(conn, table):
            return int(conn.execute(f"SELECT count(*) FROM {table}").fetchone()[0] or 0)
    except Exception:
        pass
    return 0


def _columns(conn: sqlite3.Connection, table: str) -> List[str]:
    try:
        if _table_exists(conn, table):
            return [str(r[1]) for r in conn.execute(f"PRAGMA table_info({table})").fetchall()]
    except Exception:
        pass
    return []


_BAD_FACT_VALUES = {"asking", "not asking", "unknown", "none", "null"}


def _clean_value(v: str) -> str:
    s = re.sub(r"\s+", " ", str(v or "")).strip(" .,:;!?-")
    return s


def _accept_value(v: str) -> bool:
    s = _clean_value(v).lower()
    if not s:
        return False
    if s in _BAD_FACT_VALUES:
        return False
    if len(s) > 60:
        return False
    return True


def mine_user_fact_candidates(limit: int = 12) -> List[str]:
    facts: List[str] = []
    seen = set()

    def add(line: str) -> None:
        s = _clean_value(line)
        if not s:
            return
        k = s.lower()
        if k in seen:
            return
        seen.add(k)
        facts.append(s)

    name = stored_user_name()
    if name:
        add(f"name: {name}")

    rows: List[str] = []
    conn = _conn()
    try:
        if conn is not None:
            if _table_exists(conn, "conversation_turns"):
                rows.extend(
                    str(r[0] or "")
                    for r in conn.execute(
                        """
                        SELECT COALESCE(content,'')
                        FROM conversation_turns
                        WHERE LOWER(COALESCE(role,''))='user'
                        ORDER BY id DESC
                        LIMIT 500
                        """
                    ).fetchall()
                )
            if _table_exists(conn, "memories"):
                rows.extend(
                    str(r[0] or "")
                    for r in conn.execute(
                        """
                        SELECT COALESCE(text,'')
                        FROM memories
                        ORDER BY id DESC
                        LIMIT 500
                        """
                    ).fetchall()
                )
    finally:
        if conn is not None:
            conn.close()

    for raw in rows:
        text = _clean_value(raw)
        low = text.lower()

        if "?" in text:
            continue

        for m in re.finditer(r"\bmy name is\s+([A-Za-z][A-Za-z' -]{1,30})\b", text, flags=re.I):
            val = _clean_value(m.group(1))
            if _accept_value(val):
                add(f"name: {val}")

        for m in re.finditer(
            r"\bit is\s+([A-Za-z][A-Za-z' -]{1,30})\s*,?\s*or\s*([A-Za-z][A-Za-z' -]{1,30})\s*\(nickname\)",
            text,
            flags=re.I,
        ):
            a = _clean_value(m.group(1))
            b = _clean_value(m.group(2))
            if _accept_value(a):
                add(f"name: {a}")
            if _accept_value(b):
                add(f"nickname: {b}")

        for m in re.finditer(r"\bnickname\s*[:=-]?\s*([A-Za-z][A-Za-z' -]{1,30})\b", text, flags=re.I):
            val = _clean_value(m.group(1))
            if _accept_value(val):
                add(f"nickname: {val}")

        for m in re.finditer(r"\bi prefer\s+([^.!?\n]{3,120})", text, flags=re.I):
            val = _clean_value(m.group(1))
            if val and "who " not in val.lower() and "what " not in val.lower():
                add(f"preference: {val}")

        for m in re.finditer(r"\bi use\s+([^.!?\n]{3,120})", text, flags=re.I):
            val = _clean_value(m.group(1))
            if val:
                add(f"uses: {val}")

        for m in re.finditer(r"\bi work on\s+([^.!?\n]{3,160})", text, flags=re.I):
            val = _clean_value(m.group(1))
            if val:
                add(f"work: {val}")

        if len(facts) >= limit:
            break

    return facts[:limit]


def _runtime_core() -> Dict[str, Any]:
    snap = runtime_snapshot()
    runtime = dict(snap.get("runtime") or {})
    return {
        "provider": runtime.get("provider") or snap.get("provider") or "unknown",
        "model_name": runtime.get("model_name") or snap.get("model_name") or "unknown",
        "model_path": runtime.get("model_path") or snap.get("model_path") or "unknown",
        "n_ctx": runtime.get("n_ctx") or snap.get("n_ctx") or "unknown",
        "n_gpu_layers": runtime.get("n_gpu_layers") or snap.get("n_gpu_layers") or "unknown",
        "n_threads": runtime.get("n_threads") or snap.get("n_threads") or "unknown",
        "batch_size": runtime.get("n_batch") or runtime.get("batch_size") or snap.get("n_batch") or snap.get("batch_size") or "unknown",
        "loaded": bool(runtime.get("loaded") or snap.get("loaded")),
    }


def _paths_core() -> Dict[str, Any]:
    root = _root()
    return {
        "project_root": str(root),
        "artifacts_dir": str(root / "artifacts"),
        "user_db": str(root / "artifacts/db/user.sqlite3"),
        "agent_db": str(root / "artifacts/db/agent.sqlite3"),
    }


def _format_lines(title: str, items: List[tuple[str, Any]]) -> str:
    lines = [title]
    for k, v in items:
        lines.append(f"- {k}: {v}")
    return "\n".join(lines)


def build_report(action: str, user_input: str = "") -> Dict[str, Any]:
    act = str(action or "").strip().upper()
    rt = _runtime_core()
    paths = _paths_core()

    if act in {"SELF_REPORT", "RUNTIME_STATUS"}:
        report = {
            "ok": True,
            "identity": "ELI",
            "user_name": stored_user_name(),
            "runtime": rt,
            "paths": paths,
        }
        content = _format_lines(
            "Self report:" if act == "SELF_REPORT" else "Runtime status:",
            [
                ("identity", "ELI"),
                ("provider", rt["provider"]),
                ("model_name", rt["model_name"]),
                ("model_path", rt["model_path"]),
                ("context_size", rt["n_ctx"]),
                ("gpu_layers", rt["n_gpu_layers"]),
                ("cpu_threads", rt["n_threads"]),
                ("batch_size", rt["batch_size"]),
                ("gguf_loaded_in_this_process", rt["loaded"]),
                ("project_root", paths["project_root"]),
                ("user_db", paths["user_db"]),
                ("agent_db", paths["agent_db"]),
                ("stored_user_name", stored_user_name() or "none"),
            ],
        )
        return {"ok": True, "action": act, "report": report, "content": content, "response": content}

    if act == "USER_IDENTITY_SUMMARY":
        facts = mine_user_fact_candidates(limit=12)
        report = {
            "ok": True,
            "stored_name": stored_user_name(),
            "fact_candidates": facts,
        }
        lines = ["User identity summary:"]
        lines.append(f"- stored_name: {stored_user_name() or 'none'}")
        if facts:
            lines.append("- stable_fact_candidates:")
            for fact in facts:
                lines.append(f"  - {fact}")
        else:
            lines.append("- stable_fact_candidates: none")
        content = "\n".join(lines)
        return {"ok": True, "action": act, "report": report, "content": content, "response": content}

    if act == "LAST_TRACE_REPORT":
        tr = last_trace()
        agents = tr.get("agents_used") or tr.get("agents") or []
        report = {
            "ok": True,
            "trace_available": bool(tr),
            "request_id": tr.get("request_id"),
            "reasoning_mode": tr.get("reasoning_mode"),
            "route_action": tr.get("route_action"),
            "result_action": tr.get("result_action"),
            "confidence": tr.get("confidence"),
            "agents": agents,
            "plan": tr.get("plan") or "none",
            "route_meta": tr.get("route_meta") or {},
            "result_meta": tr.get("result_meta") or {},
        }
        content = _format_lines(
            "Last trace:",
            [
                ("trace_available", report["trace_available"]),
                ("request_id", report["request_id"]),
                ("reasoning_mode", report["reasoning_mode"]),
                ("route_action", report["route_action"]),
                ("result_action", report["result_action"]),
                ("confidence", report["confidence"]),
                ("agents", report["agents"]),
                ("plan", report["plan"]),
                ("route_meta", report["route_meta"]),
                ("result_meta", report["result_meta"]),
            ],
        )
        return {"ok": True, "action": act, "report": report, "content": content, "response": content}

    if act == "PERSONA_AUTO_REPORT":
        p = _root() / "eli/cognition/persona.auto.txt"
        body = ""
        if p.exists():
            try:
                body = p.read_text(encoding="utf-8", errors="replace").strip()
            except Exception as e:
                body = f"<read_error: {e}>"
        report = {"ok": True, "path": str(p), "exists": p.exists(), "size_bytes": p.stat().st_size if p.exists() else 0}
        content = "\n".join(
            [
                f"persona.auto.txt exists: {report['exists']}",
                f"path: {report['path']}",
                f"size_bytes: {report['size_bytes']}",
                body[:4000],
            ]
        ).strip()
        return {"ok": True, "action": act, "report": report, "content": content, "response": content}

    if act == "IMPORT_AUDIT":
        modules = [
            "eli.kernel.engine",
            "eli.cognition.orchestrator",
            "eli.cognition.agent_bus",
            "eli.cognition.gguf_inference",
            "eli.memory.memory",
            "eli.execution.router_enhanced",
            "eli.execution.executor_enhanced",
            "eli.gui.eli_pro_audio_gui_MKI",
            "eli.planning.proactive_daemon",
        ]
        entries = []
        for mod in modules:
            try:
                importlib.import_module(mod)
                entries.append({"module": mod, "status": "PASS", "error": "", "suggested_fix": ""})
            except Exception as e:
                entries.append({"module": mod, "status": "FAIL", "error": repr(e), "suggested_fix": "inspect import path and syntax"})
        content = "\n".join(f"{e['module']} | {e['status']} | {e['error'] or '-'} | {e['suggested_fix'] or '-'}" for e in entries)
        return {"ok": True, "action": act, "report": {"ok": True, "entries": entries}, "content": content, "response": content}

    if act == "RUNTIME_AUDIT":
        files = [
            "eli/kernel/engine.py",
            "eli/cognition/orchestrator.py",
            "eli/cognition/agent_bus.py",
            "eli/cognition/working_memory.py",
            "eli/cognition/gguf_inference.py",
            "eli/execution/router_enhanced.py",
            "eli/execution/executor_enhanced.py",
            "eli/gui/eli_pro_audio_gui_MKI.py",
            "eli/planning/proactive_daemon.py",
            "eli/memory/memory.py",
            "eli/core/paths.py",
        ]
        entries = []
        for rel in files:
            p = _root() / rel
            entries.append({"path": str(p), "status": "PASS" if p.exists() else "FAIL", "issues": [] if p.exists() else [{"type": "missing_file", "line": 0, "message": "file not found"}]})
        content_lines = []
        for e in entries:
            content_lines.append(f"{e['status']} {e['path']}")
            for issue in e["issues"]:
                content_lines.append(f"  - line {issue['line'] or '?'} [{issue['type']}] {issue['message']}")
        content = "\n".join(content_lines)
        return {"ok": True, "action": act, "report": {"ok": True, "entries": entries}, "content": content, "response": content}

    if act == "EXPLAIN_COGNITION_RUNTIME":
        stage_names = [
            "1. PERCEIVE + INGEST",
            "2. INPUT NORMALIZATION + GUARDS",
            "3. ROUTER + TASK DECOMPOSER",
            "4. TRUTH / GROUNDING GATE",
            "5. EXECUTIVE CONTROLLER / PLANNER",
            "6. AGENT BUS",
            "7. WORKING MEMORY / CONTEXT ASSEMBLER",
            "8. SINGLE INFERENCE BROKER",
            "9. REASONING / SYNTHESIS LAYER",
            "10. OUTPUT GOVERNOR",
            "11. RESPONSE DELIVERY",
            "12. LEARNING + STATE UPDATE",
        ]
        files = [
            "eli/kernel/engine.py",
            "eli/cognition/orchestrator.py",
            "eli/cognition/agent_bus.py",
            "eli/cognition/working_memory.py",
            "eli/cognition/gguf_inference.py",
            "eli/execution/router_enhanced.py",
            "eli/execution/executor_enhanced.py",
            "eli/gui/eli_pro_audio_gui_MKI.py",
            "eli/kernel/pipeline.py",
            "eli/planning/proactive_daemon.py",
        ]
        report = {
            "ok": True,
            "live_orchestration_surface": str(_root() / "eli/kernel/engine.py"),
            "cognitive_engine_class_in_engine_py": True,
            "process_method_in_engine_py": True,
            "internal_orchestrator_ref": True,
            "pipeline_stage_count": 12,
            "pipeline_stage_names": stage_names,
            "files": [{"path": str(_root() / f), "exists": (_root() / f).exists()} for f in files],
        }
        content = "\n".join(
            [
                "Cognition runtime surface:",
                f"- live_orchestration_surface: {report['live_orchestration_surface']}",
                "- note: the live CognitiveEngine class is inside eli/kernel/engine.py",
                f"- pipeline_stage_count: {report['pipeline_stage_count']}",
                f"- pipeline_stage_names: {report['pipeline_stage_names']}",
                f"- files: {report['files']}",
            ]
        )
        return {"ok": True, "action": act, "report": report, "content": content, "response": content}

    if act == "EXPLAIN_MEMORY_RUNTIME":
        conn = _conn()
        tables = {}
        counts = {}
        if conn is not None:
            try:
                for t in ["memories", "conversation_turns", "observations", "recall_log", "habits", "improvements", "memories_fts"]:
                    if _table_exists(conn, t):
                        tables[t] = _columns(conn, t)
                        counts[t] = _count(conn, t)
            finally:
                conn.close()

        files = [
            "eli/memory/memory.py",
            "eli/memory/memory_adapter.py",
            "eli/memory/memory_service.py",
            "eli/memory/knowledge_graph.py",
            "eli/memory/vector_store.py",
            "eli/kernel/state.py",
            "eli/kernel/world_model.py",
            "eli/runtime/persistence_gate.py",
            "eli/planning/proactive_daemon.py",
        ]
        report = {
            "ok": True,
            "files": [{"path": str(_root() / f), "exists": (_root() / f).exists()} for f in files],
            "tables": tables,
            "counts": counts,
            "stored_name": stored_user_name(),
        }
        content = "\n".join(
            [
                "Memory runtime surface:",
                f"- files: {report['files']}",
                f"- tables: {report['tables']}",
                f"- counts: {report['counts']}",
                f"- stored_name: {report['stored_name'] or 'none'}",
            ]
        )
        return {"ok": True, "action": act, "report": report, "content": content, "response": content}

    if act == "SMALL_TALK_GREETING":
        content = f"Online. identity=ELI; user={stored_user_name() or 'unknown'}; model={rt['model_name']}; ctx={rt['n_ctx']}; gpu_layers={rt['n_gpu_layers']}."
        return {"ok": True, "action": act, "report": {"ok": True}, "content": content, "response": content}

    content = f"Unhandled live introspection action: {act}"
    return {"ok": False, "action": act, "report": {"ok": False}, "content": content, "response": content}


def agents_for_action(action: str) -> List[str]:
    act = str(action or "").strip().upper()
    if act in {"SELF_REPORT", "RUNTIME_STATUS", "IMPORT_AUDIT", "RUNTIME_AUDIT"}:
        return ["introspection", "file_code"]
    if act in {"USER_IDENTITY_SUMMARY", "EXPLAIN_MEMORY_RUNTIME"}:
        return ["introspection", "memory", "file_code"]
    if act == "EXPLAIN_COGNITION_RUNTIME":
        return ["introspection", "file_code", "reflection"]
    if act == "LAST_TRACE_REPORT":
        return ["introspection"]
    if act == "PERSONA_AUTO_REPORT":
        return ["introspection", "file_code"]
    if act == "SMALL_TALK_GREETING":
        return ["introspection"]
    return ["introspection"]

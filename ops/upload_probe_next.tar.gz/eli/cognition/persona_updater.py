"""
brain.awareness.persona_updater
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Runs the persona auto-overlay update at boot and after reflection cycles.
Replaces the need to manually run scripts/persona_autoupdate_from_db.py.

Called from boot_awareness() and from the reflection cycle in the
cognitive engine.
"""

from __future__ import annotations
from pathlib import Path
import re

import logging
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)


def _safe_call(obj: Any, name: str, *args, **kwargs):
    fn = getattr(obj, name, None)
    if callable(fn):
        try:
            return fn(*args, **kwargs)
        except Exception:
            return None
    return None


def _clean(value: Any) -> str:
    return " ".join(str(value or "").split()).strip()


def _top_lines(rows: Any, key: str, limit: int = 8) -> List[str]:
    """Extract text lines from memory rows, filtering out raw user chat messages."""
    import re as _re
    # Raw conversational messages should never go into the persona overlay
    _chat_noise = _re.compile(
        r"^(hey|hi|hello|do you|can you|what|how|who|you mean|that is|i am|"
        r"sure|ok|yes|no|please|thanks|haha|lol|hm|hmm|i think|i want|"
        r"let me|tell me|give me|show me|help me|could you|would you)",
        _re.I
    )
    out: List[str] = []
    if not rows:
        return out
    for row in rows[:limit * 3]:  # scan more to find non-noise entries
        text = _clean(row.get(key) if isinstance(row, dict) else "")
        if not text:
            continue
        # Skip raw conversational user messages
        if _chat_noise.match(text):
            continue
        # Skip very short entries (likely noise)
        if len(text) < 20:
            continue
        out.append(text[:220])
        if len(out) >= limit:
            break
    return out


def _habit_lines(mem: Any) -> List[str]:
    rules = _safe_call(mem, "get_habit_rules", enabled_only=False) or []
    out: List[str] = []
    for row in rules[:10]:
        if not isinstance(row, dict):
            continue
        name = _clean(row.get("name", ""))
        command = _clean(row.get("command", ""))
        hour = row.get("hour", 0)
        minute = row.get("minute", 0)
        enabled = bool(row.get("enabled", False))
        label = f"{name or 'unnamed'} @ {int(hour):02d}:{int(minute):02d}"
        if command:
            label += f" -> {command[:120]}"
        label += " [enabled]" if enabled else " [disabled]"
        out.append(label)
    return out


def _dedup_lines(lines: List[str]) -> List[str]:
    """Remove exact duplicates, keep order, keep last occurrence."""
    seen = set()
    result = []
    for line in reversed(lines):
        key = line.strip().lower()
        if key not in seen:
            seen.add(key)
            result.append(line)
    result.reverse()
    return result

def _sanitize_release_overlay_text(text: str) -> str:
    text = text or ""

    line_rules = [
        (r'(?m)^- Runtime status:.*$', '- Runtime status: sanitized'),
        (r'(?m)^- Cognition runtime:.*$', '- Cognition runtime: sanitized'),
        (r'(?m)^- Memory recall:.*$', '- Memory recall: sanitized'),
    ]
    for patt, repl in line_rules:
        text = re.sub(patt, repl, text)

    inline_rules = [
        (r'(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b', '<LOCAL_EMAIL>'),
        (r'(?<![A-Za-z0-9_])/(?:home|Users|mnt)/\S+', '<LOCAL_PATH>'),
        (r'\b[A-Za-z]:\\\S+', '<LOCAL_PATH>'),
    ]
    for patt, repl in inline_rules:
        text = re.sub(patt, repl, text)

    return text

def _post_sanitize_overlay_file(path) -> bool:
    try:
        path = Path(path)
        raw = path.read_text(encoding='utf-8', errors='replace')
        clean = _sanitize_release_overlay_text(raw)
        if clean != raw:
            path.write_text(clean, encoding='utf-8')
            return True
    except Exception:
        return False
    return False

def update_persona_overlay(memory: Any = None) -> Dict[str, Any]:
    """
    Rebuild persona.auto.txt from current memory state.
    This file contains ELI's evolving persona — habits, reflections,
    self-improvement notes, and failure patterns.

    User profile data (name, preferences, working style) is stored
    separately in user_profile.json via update_user_profile_overlay().

    Returns {"ok": bool, "changed": bool, "sections": int}.
    """
    if memory is None:
        try:
            from eli.memory import get_memory
            memory = get_memory()
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    try:
        from eli.cognition.persona import update_auto_sections
    except Exception as exc:
        return {"ok": False, "error": f"persona.update_auto_sections unavailable: {exc}"}

    # Gather ELI-specific data from memory
    observations = _safe_call(memory, "get_recent_observations", limit=8) or []
    improvements = _safe_call(memory, "get_recent_improvements", limit=8) or []
    failures = _safe_call(memory, "get_recent_failures", limit=5) or []
    summaries = _safe_call(memory, "get_recent_semantic_memories", limit=6) or []

    # ELI's persona sections only — no user profile data here
    sections = {
        "Runtime Persona Notes": [
            "This file is ELI's auto-updating persona overlay.",
            "User profile (name, preferences) is stored separately in user_profile.json.",
            "Prefer concrete continuity, memory-backed context, and direct language.",
        ],
        "Habits (Auto-Updated)": _dedup_lines(_habit_lines(memory)),
        "Reflection / Observations (Auto-Updated)": _dedup_lines(
            _top_lines(observations, "observation", limit=8)
        ),
        "Self Improvement (Auto-Updated)": _dedup_lines(
            _top_lines(improvements, "description", limit=8)
        ),
        "Recent Failure Patterns (Auto-Updated)": _dedup_lines(
            _top_lines(failures, "error", limit=5)
        ),
        "Processed Memory Themes (Auto-Updated)": _dedup_lines(
            _top_lines(summaries, "text", limit=6)
        ),
    }

    try:
        update_auto_sections(sections)
        log.info("persona_updater: overlay updated (%d sections)", len(sections))
    except Exception as exc:
        log.warning("persona_updater: failed: %s", exc)
        return {"ok": False, "error": str(exc)}

    # Also update the user profile file from identity signals in memory
    update_user_profile_overlay(memory)
    return {"ok": True, "changed": True, "sections": len(sections)}


def update_user_profile_overlay(memory: Any = None) -> Dict[str, Any]:
    """
    Update user_profile.json from identity signals discovered in memory.
    This is separate from ELI's persona — it captures who the USER is,
    not who ELI is.
    """
    try:
        from eli.kernel.state import load_user_profile, update_user_profile, get_user_name
    except Exception as exc:
        return {"ok": False, "error": str(exc)}

    updates: Dict[str, Any] = {}

    # Authoritative name from state.json always wins
    name = get_user_name().strip()
    if name:
        updates["name"] = name

    if memory is not None:
        # Search for stated preferences / working style in memory
        try:
            pref_hits = _safe_call(
                memory, "search_memory", "prefer like working style", limit=8
            ) or []
            import re as _pref_re
            # Reject conversational noise: questions, greetings, rhetorical phrases
            _pref_noise = _pref_re.compile(
                r"[?!]|^\s*(hey|hi|hello|do you|can you|what|how|who|why|very|seriously"
                r"|haha|lol|sure|ok|yes|no|please|thanks|tell me|give me|show me"
                r"|help me|could you|would you|do you know|are you)",
                _pref_re.I,
            )
            new_prefs = []
            for h in pref_hits:
                txt = _clean(h.get("text") or h.get("content") or "")
                # Only include short, declarative preference statements — no questions
                if (txt and 10 < len(txt) < 100
                        and not _pref_noise.search(txt)
                        and any(w in txt.lower() for w in ("i prefer", "i like", "i want",
                            "i always", "i never", "i use", "i enjoy", "i need",
                            "prefer to", "like to", "want to"))):
                    new_prefs.append(txt)
            if new_prefs:
                updates["preferences"] = new_prefs[:5]
        except Exception:
            pass

    if updates:
        try:
            update_user_profile(updates)
            log.info("persona_updater: user profile updated: %s", list(updates.keys()))
            return {"ok": True, "updated": list(updates.keys())}
        except Exception as exc:
            log.warning("persona_updater: user profile update failed: %s", exc)
            return {"ok": False, "error": str(exc)}

    return {"ok": True, "updated": []}

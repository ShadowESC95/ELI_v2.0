from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict

from eli.core.paths import get_paths


_BAD_NAMES = {"asking", "[user]", "<user>", "<username>", "<local_user>", "unknown", "none"}


def _runtime_dir() -> Path:
    p = Path(get_paths().artifacts_dir) / "runtime"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _state_path() -> Path:
    return _runtime_dir() / "state.json"


def _profile_path() -> Path:
    return _runtime_dir() / "user_profile.json"


def _read_json(path: Path, default: Dict[str, Any]) -> Dict[str, Any]:
    try:
        if path.exists():
            obj = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(obj, dict):
                return obj
    except Exception:
        pass
    return dict(default)


def _write_json(path: Path, data: Dict[str, Any]) -> Dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return data


def load_state() -> Dict[str, Any]:
    return _read_json(_state_path(), {})


def save_state(state: Dict[str, Any]) -> Dict[str, Any]:
    return _write_json(_state_path(), dict(state or {}))


def load_user_profile() -> Dict[str, Any]:
    return _read_json(_profile_path(), {})


def save_user_profile(profile: Dict[str, Any]) -> Dict[str, Any]:
    return _write_json(_profile_path(), dict(profile or {}))


def _clean_name(name: str) -> str:
    n = str(name or "").strip()
    return "" if n.lower() in _BAD_NAMES else n


def get_user_name(default: str = "") -> str:
    state = load_state()
    return _clean_name(str(state.get("user_name", default) or ""))


def set_user_name(name: str) -> str:
    n = _clean_name(name)
    state = load_state()
    profile = load_user_profile()

    if n:
        state["user_name"] = n
        profile["name"] = n
    else:
        state.pop("user_name", None)
        if _clean_name(str(profile.get("name", "") or "")) == "":
            profile.pop("name", None)

    save_state(state)
    save_user_profile(profile)
    sync_identity_to_world_model()
    return n


def clear_user_name() -> None:
    set_user_name("")


def update_user_profile(update: Dict[str, Any] | None = None, **kwargs: Any) -> Dict[str, Any]:
    profile = load_user_profile()
    if update:
        profile.update(dict(update))
    if kwargs:
        profile.update(kwargs)

    if _clean_name(str(profile.get("name", "") or "")) == "":
        profile.pop("name", None)

    save_user_profile(profile)
    return profile


def get_user_profile_text() -> str:
    profile = load_user_profile()
    name = get_user_name("") or _clean_name(str(profile.get("name", "") or ""))

    lines = []
    if name:
        lines.append(f"Name: {name}")

    for k, v in profile.items():
        if k == "name":
            continue
        if v is None:
            continue
        s = str(v).strip()
        if not s:
            continue
        lines.append(f"{k}: {s}")

    return "\n".join(lines).strip()


def world_model_snapshot_bridge():
    try:
        from eli.kernel.world_model import world_model_snapshot
        return world_model_snapshot()
    except Exception:
        return {}


def sync_identity_to_world_model() -> None:
    try:
        from eli.kernel.world_model import get_world_model, save_world_model
        wm = get_world_model()
        n = get_user_name("").strip()
        wm.identity.preferred_name = n
        wm.identity.confidence = 1.0 if n else 0.0
        wm.identity.updated_at = time.time()
        save_world_model(wm)
    except Exception:
        pass


__all__ = [
    "load_state",
    "save_state",
    "load_user_profile",
    "save_user_profile",
    "get_user_name",
    "set_user_name",
    "clear_user_name",
    "update_user_profile",
    "get_user_profile_text",
    "world_model_snapshot_bridge",
    "sync_identity_to_world_model",
]



from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

from eli.core.paths import get_paths


def _settings_file() -> Path:
    # 1. Explicit override (dev, testing, portable installs)
    env = os.environ.get("ELI_SETTINGS_FILE")
    if env:
        return Path(env).expanduser().resolve()

    # 2. Canonical: project-relative in dev mode, platformdirs user_config otherwise.
    # This is resolved once by core.paths; do not second-guess it here.
    try:
        return (get_paths().config_dir / "settings.json").resolve()
    except Exception:
        pass

    # 3. Final fallback
    return Path(os.environ.get("ELI_SETTINGS_PATH", str(Path(os.environ.get("ELI_CONFIG_DIR", "config")) / "settings.json"))).expanduser().resolve()


SETTINGS_FILE = _settings_file()

# Canonical keys. Legacy duplicates (`gpu_layers`, `cpu_threads`) are migrated
# into these on first load and then removed from the file.
DEFAULTS: Dict[str, Any] = {
    "provider": "custom_gguf",
    "model_path": "",
    "bundled_model_path": "",
    "custom_model_path": "",
    "ollama_host": "http://localhost:11434",
    "ollama_model": "",
    "persona_file": "",
    "user_name": "",
    "user_text_color": "#4DA3FF",
    "n_ctx": 16384,
    "max_tokens": 2048,
    "temperature": 0.7,
    "top_p": 0.95,
    "top_k": 40,
    "repeat_penalty": 1.1,
    "n_gpu_layers": 99,
    "n_threads": max(1, os.cpu_count() or 8),
    "batch_size": 512,
    "use_mmap": True,
    "use_mlock": False,
    "auto_speak": False,
    "mic_enabled": False,
    "quick_mode": "Quick",
    "auto_save": True,
    "log_to_file": False,
    "auto_load": True,
    "first_run_complete": False,
    "theme": "dark",
}

ENV_TO_KEY = {
    "ELI_PROVIDER": "provider",
    "ELI_MODEL_PATH": "model_path",
    "ELI_GGUF_MODEL_PATH": "model_path",
    "ELI_BUNDLED_MODEL_PATH": "bundled_model_path",
    "ELI_CUSTOM_MODEL_PATH": "custom_model_path",
    "ELI_OLLAMA_HOST": "ollama_host",
    "ELI_OLLAMA_MODEL": "ollama_model",
    "ELI_PERSONA_FILE": "persona_file",
    "ELI_USER_NAME": "user_name",
    "ELI_USER_TEXT_COLOR": "user_text_color",
    "ELI_N_CTX": "n_ctx",
    "ELI_MAX_TOKENS": "max_tokens",
    "ELI_TEMPERATURE": "temperature",
    "ELI_TOP_P": "top_p",
    "ELI_TOP_K": "top_k",
    "ELI_REPEAT_PENALTY": "repeat_penalty",
    "ELI_N_GPU_LAYERS": "n_gpu_layers",
    "ELI_GPU_LAYERS": "n_gpu_layers",         # legacy env name; same canonical key
    "ELI_N_THREADS": "n_threads",
    "ELI_CPU_THREADS": "n_threads",           # legacy env name
    "ELI_BATCH_SIZE": "batch_size",
    "ELI_USE_MMAP": "use_mmap",
    "ELI_USE_MLOCK": "use_mlock",
    "ELI_AUTO_SPEAK": "auto_speak",
    "ELI_MIC_ENABLED": "mic_enabled",
    "ELI_QUICK_MODE": "quick_mode",
    "ELI_AUTO_SAVE": "auto_save",
    "ELI_LOG_TO_FILE": "log_to_file",
    "ELI_AUTO_LOAD": "auto_load",
    "ELI_THEME": "theme",
}

# Legacy keys to migrate and then remove from the file.
LEGACY_KEY_MIGRATIONS = {
    "gpu_layers": "n_gpu_layers",
    "cpu_threads": "n_threads",
}

INT_KEYS = {"n_ctx", "max_tokens", "top_k", "n_gpu_layers", "n_threads", "batch_size"}
FLOAT_KEYS = {"temperature", "top_p", "repeat_penalty"}
BOOL_KEYS = {"use_mmap", "use_mlock", "auto_speak", "mic_enabled",
             "auto_save", "log_to_file", "auto_load", "first_run_complete"}

_MIGRATION_LOGGED = False


def _coerce_value(key: str, value: Any) -> Any:
    if key in BOOL_KEYS:
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in {"1", "true", "yes", "on"}
    if key in INT_KEYS:
        try:
            return int(value)
        except Exception:
            return DEFAULTS.get(key)
    if key in FLOAT_KEYS:
        try:
            return float(value)
        except Exception:
            return DEFAULTS.get(key)
    return value


def _migrate_legacy_keys(data: Dict[str, Any]) -> tuple[Dict[str, Any], list[str]]:
    """Fold legacy keys into canonical ones. Returns (migrated_data, list_of_migrated_keys)."""
    migrated: list[str] = []
    out = dict(data)
    for old_key, new_key in LEGACY_KEY_MIGRATIONS.items():
        if old_key in out:
            # Only copy the legacy value if the canonical key is absent OR matches default.
            # Prefer the canonical value if both exist (user edited GUI -> n_gpu_layers).
            if new_key not in out:
                out[new_key] = out[old_key]
            del out[old_key]
            migrated.append(old_key)
    return out, migrated


def load_settings() -> Dict[str, Any]:
    global _MIGRATION_LOGGED
    settings = dict(DEFAULTS)
    settings_file = _settings_file()

    raw: Dict[str, Any] = {}
    if settings_file.exists():
        try:
            parsed = json.loads(settings_file.read_text(encoding="utf-8"))
            if isinstance(parsed, dict):
                raw = parsed
        except Exception:
            pass

    # Migrate legacy keys in-memory AND persist the cleaned file
    migrated_data, migrated_keys = _migrate_legacy_keys(raw)
    if migrated_keys:
        try:
            settings_file.parent.mkdir(parents=True, exist_ok=True)
            settings_file.write_text(
                json.dumps(migrated_data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            if not _MIGRATION_LOGGED:
                print(f"[SETTINGS] Migrated {len(migrated_keys)} legacy keys: {migrated_keys}")
                _MIGRATION_LOGGED = True
        except Exception as e:
            print(f"[SETTINGS] Migration save failed (non-fatal): {e}")

    settings.update(migrated_data)

    for env_name, key in ENV_TO_KEY.items():
        val = os.environ.get(env_name)
        if val not in (None, ""):
            settings[key] = _coerce_value(key, val)

    # Canonical coercion (no more dual-key fallbacks)
    settings["n_threads"] = int(settings.get("n_threads", DEFAULTS["n_threads"]))
    settings["n_gpu_layers"] = int(settings.get("n_gpu_layers", DEFAULTS["n_gpu_layers"]))
    settings["gpu_layers"] = settings["n_gpu_layers"]

    if not settings.get("model_path"):
        settings["model_path"] = (
            settings.get("custom_model_path")
            or settings.get("bundled_model_path")
            or ""
        )

    return settings


def save_settings(settings: Dict[str, Any]) -> None:
    """Merge-save: read current file, apply updates, strip legacy keys, write back."""
    settings_file = _settings_file()

    # Start from whatever is on disk (NOT defaults — so we don't reintroduce defaults
    # into the file if the user has never touched them).
    existing: Dict[str, Any] = {}
    if settings_file.exists():
        try:
            parsed = json.loads(settings_file.read_text(encoding="utf-8"))
            if isinstance(parsed, dict):
                existing = parsed
        except Exception:
            pass

    # Migrate anything legacy in existing first
    existing, _ = _migrate_legacy_keys(existing)

    # Apply caller updates
    for k, v in settings.items():
        if k in LEGACY_KEY_MIGRATIONS:
            # If caller passed a legacy key, fold it silently
            existing[LEGACY_KEY_MIGRATIONS[k]] = v
        else:
            existing[k] = v

    # Final coercion on canonical keys
    if "n_threads" in existing:
        try: existing["n_threads"] = int(existing["n_threads"])
        except Exception: pass
    if "n_gpu_layers" in existing:
        try:
            existing["n_gpu_layers"] = int(existing["n_gpu_layers"])
            existing["gpu_layers"] = existing["n_gpu_layers"]
        except Exception:
            pass

    settings_file.parent.mkdir(parents=True, exist_ok=True)
    settings_file.write_text(
        json.dumps(existing, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def update_settings(**kwargs: Any) -> Dict[str, Any]:
    """Convenience: save specific keys, return the full new state."""
    save_settings(kwargs)
    return load_settings()


def load_runtime_settings() -> Dict[str, Any]:
    return load_settings()


def save_runtime_settings(settings: Dict[str, Any]) -> None:
    save_settings(settings)


def apply_env(settings=None):
    s = dict(load_settings() if settings is None else settings)

    n_ctx = int(s.get("n_ctx", DEFAULTS["n_ctx"]) or DEFAULTS["n_ctx"])
    n_batch = int(s.get("batch_size", DEFAULTS["batch_size"]) or DEFAULTS["batch_size"])
    n_threads = int(s.get("n_threads", DEFAULTS["n_threads"]) or DEFAULTS["n_threads"])
    n_gpu_layers = int(s.get("n_gpu_layers", DEFAULTS["n_gpu_layers"]) or DEFAULTS["n_gpu_layers"])
    max_tokens = int(s.get("max_tokens", DEFAULTS["max_tokens"]) or DEFAULTS["max_tokens"])

    os.environ["ELI_GGUF_N_CTX"] = str(n_ctx)
    os.environ["ELI_GGUF_N_BATCH"] = str(n_batch)
    os.environ["ELI_GGUF_THREADS"] = str(n_threads)
    os.environ["ELI_GGUF_N_GPU_LAYERS"] = str(n_gpu_layers)
    os.environ["ELI_MAX_TOKENS"] = str(max_tokens)

    # legacy mirrors for older callers still reading the non-GGUF names
    os.environ["ELI_N_CTX"] = str(n_ctx)
    os.environ["ELI_BATCH_SIZE"] = str(n_batch)
    os.environ["ELI_N_THREADS"] = str(n_threads)
    os.environ["ELI_N_GPU_LAYERS"] = str(n_gpu_layers)

    os.environ["ELI_GGUF_USE_MMAP"] = "1" if bool(s.get("use_mmap", True)) else "0"
    os.environ["ELI_GGUF_USE_MLOCK"] = "1" if bool(s.get("use_mlock", False)) else "0"

    model_path = str(
        s.get("model_path", "")
        or s.get("custom_model_path", "")
        or s.get("bundled_model_path", "")
    ).strip()
    if model_path:
        os.environ["ELI_GGUF_MODEL_PATH"] = model_path

    return s


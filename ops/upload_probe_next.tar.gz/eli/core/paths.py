"""
ELI Path Resolution — Single Source of Truth
==============================================
All modules MUST use this module for path resolution.
Never construct data/config/cache paths elsewhere.

Supports three modes:
  1. Development: ELI_DATA_DIR env var or running from source tree
  2. Installed package: platformdirs for platform-standard directories  
  3. Frozen app: sys._MEIPASS for PyInstaller bundles

Usage:
    from eli.core.paths import (
        data_dir, config_dir, cache_dir, logs_dir,
        models_dir, plugins_dir, voices_dir, db_dir,
        user_db_path, agent_db_path, memory_db_path,
        artifacts_dir, project_root,
    )
"""

import os
import sys
import logging
from pathlib import Path
from functools import lru_cache

log = logging.getLogger(__name__)

_APP_NAME = "eli"
_APP_AUTHOR = "eli"

# ── Frozen app detection (PyInstaller / cx_Freeze) ──

def is_frozen() -> bool:
    """True if running as a frozen (PyInstaller/cx_Freeze) bundle."""
    return getattr(sys, 'frozen', False)

def _frozen_base() -> Path:
    """Base directory for frozen app resources."""
    if hasattr(sys, '_MEIPASS'):
        return Path(sys._MEIPASS)
    return Path(sys.executable).parent


# ── Source tree detection ──

def _find_project_root() -> Path | None:
    """Walk up from this file to find the project root (contains pyproject.toml)."""
    p = Path(__file__).resolve().parent
    for _ in range(5):
        if (p / "pyproject.toml").exists():
            return p
        p = p.parent
    return None

@lru_cache(maxsize=1)
def project_root() -> Path:
    """
    Project root directory.
    - Frozen: executable directory
    - Dev/installed: directory containing pyproject.toml
    """
    if is_frozen():
        return _frozen_base()
    root = _find_project_root()
    if root:
        return root
    # Fallback: assume we're in a subdirectory of the project
    return Path(__file__).resolve().parent.parent


# ── Dev-mode detection ──

def _is_dev_mode() -> bool:
    """True if running from a source tree (not installed or frozen)."""
    if is_frozen():
        return False
    root = _find_project_root()
    if root is None:
        return False
    # Source layout: project_root/eli/brain and project_root/eli/gui
    eli_pkg = root / "eli"
    if eli_pkg.is_dir() and (eli_pkg / "brain").is_dir() and (eli_pkg / "gui").is_dir():
        return True
    # Legacy flat layout: project_root/brain and project_root/gui
    if (root / "brain").is_dir() and (root / "gui").is_dir():
        return True
    return False


# ── Platform-aware directories ──

def _get_platformdirs():
    """Import platformdirs, falling back to hardcoded XDG if unavailable."""
    try:
        import platformdirs
        return platformdirs
    except ImportError:
        return None

@lru_cache(maxsize=1)
def data_dir() -> Path:
    """
    Persistent user data: databases, conversations, persona, notes.
    Override: ELI_DATA_DIR env var.
    Dev mode: <project_root>/artifacts
    Installed: ~/.local/share/eli (Linux), %LOCALAPPDATA%/eli (Win), ~/Library/Application Support/eli (Mac)
    """
    override = os.environ.get("ELI_DATA_DIR")
    if override:
        return Path(override).expanduser().resolve()
    
    if _is_dev_mode():
        return project_root() / "artifacts"
    
    pd = _get_platformdirs()
    if pd:
        return Path(pd.user_data_dir(_APP_NAME, _APP_AUTHOR))
    
    # Manual fallback
    if sys.platform == "win32":
        return Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / _APP_NAME
    elif sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / _APP_NAME
    else:
        return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / _APP_NAME

@lru_cache(maxsize=1)
def config_dir() -> Path:
    """
    Configuration files: config.yaml, user_id, settings.json.
    Override: ELI_CONFIG_DIR env var.
    Dev mode: <project_root>/config
    Installed: ~/.config/eli (Linux), %APPDATA%/eli (Win), ~/Library/Preferences/eli (Mac)
    """
    override = os.environ.get("ELI_CONFIG_DIR")
    if override:
        return Path(override).expanduser().resolve()
    
    if _is_dev_mode():
        return project_root() / "config"
    
    pd = _get_platformdirs()
    if pd:
        return Path(pd.user_config_dir(_APP_NAME, _APP_AUTHOR))
    
    if sys.platform == "win32":
        return Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming")) / _APP_NAME
    elif sys.platform == "darwin":
        return Path.home() / "Library" / "Preferences" / _APP_NAME
    else:
        return Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / _APP_NAME

@lru_cache(maxsize=1)
def cache_dir() -> Path:
    """
    Temporary/cache data: model caches, compiled assets.
    Override: ELI_CACHE_DIR env var.
    Dev mode: <project_root>/cache
    Installed: ~/.cache/eli (Linux), %LOCALAPPDATA%/eli/cache (Win), ~/Library/Caches/eli (Mac)
    """
    override = os.environ.get("ELI_CACHE_DIR")
    if override:
        return Path(override).expanduser().resolve()
    
    if _is_dev_mode():
        return project_root() / "cache"
    
    pd = _get_platformdirs()
    if pd:
        return Path(pd.user_cache_dir(_APP_NAME, _APP_AUTHOR))
    
    if sys.platform == "win32":
        return Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / _APP_NAME / "cache"
    elif sys.platform == "darwin":
        return Path.home() / "Library" / "Caches" / _APP_NAME
    else:
        return Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / _APP_NAME


# ── Derived directories ──

def db_dir() -> Path:
    """SQLite database directory."""
    return data_dir() / "db" if not _is_dev_mode() else data_dir()

def logs_dir() -> Path:
    """Log files directory."""
    return data_dir() / "logs"

def models_dir() -> Path:
    """GGUF model files directory."""
    override = os.environ.get("ELI_MODELS_DIR")
    if override:
        return Path(override).expanduser().resolve()
    if _is_dev_mode():
        return project_root() / "models"
    return data_dir() / "models"

def voices_dir() -> Path:
    """Voice model files (Piper ONNX)."""
    if _is_dev_mode():
        return project_root() / "voices"
    return data_dir() / "voices"

def plugins_dir() -> Path:
    """User-installed plugins."""
    if _is_dev_mode():
        return project_root() / "plugins"
    return data_dir() / "plugins"

def artifacts_dir() -> Path:
    """Alias for data_dir() — backward compat with existing code."""
    return data_dir()

def conversations_dir() -> Path:
    """Conversation log directory."""
    return data_dir() / "conversations"

def proactive_dir() -> Path:
    """Proactive daemon state directory."""
    return data_dir() / "proactive"

def documents_dir() -> Path:
    """Generated documents directory."""
    return data_dir() / "documents"

def scripts_dir() -> Path:
    """User-generated scripts directory."""
    return data_dir() / "scripts"

def notes_dir() -> Path:
    """User notes directory."""
    return data_dir() / "notes"


# ── Database paths ──

def user_db_path() -> Path:
    """Primary user database (conversations, memories)."""
    override = os.environ.get("ELI_USER_DB")
    if override:
        return Path(override).expanduser().resolve()
    return db_dir() / "user.sqlite3"

def agent_db_path() -> Path:
    """Agent bus state database."""
    override = os.environ.get("ELI_AGENT_DB")
    if override:
        return Path(override).expanduser().resolve()
    return db_dir() / "agent.sqlite3"

def memory_db_path() -> Path:
    """Dedicated semantic memory + knowledge store (user.sqlite3).
    Separate from user.sqlite3 (conversations/state) and agent.sqlite3 (agent bus).
    """
    return db_dir() / "user.sqlite3"  # CONSOLIDATED: single canonical DB


def knowledge_graph_db_path() -> Path:
    """Knowledge graph lives inside user.sqlite3 as extra tables."""
    return memory_db_path()


# ── Persona paths ──

def persona_base_path() -> Path:
    """Base persona text file."""
    if _is_dev_mode():
        return project_root() / "eli" / "brain" / "persona" / "persona.txt"
    return config_dir() / "persona.txt"

def persona_auto_path() -> Path:
    """Auto-generated persona file."""
    if _is_dev_mode():
        return project_root() / "eli" / "brain" / "persona" / "persona.auto.txt"
    return config_dir() / "persona.auto.txt"


# ── Notebook ──

def notebook_dir() -> Path:
    """ELI notebook / journal directory."""
    if _is_dev_mode():
        return project_root() / "eli_notebook"
    return data_dir() / "notebook"


# ── Ensure directories exist ──

def ensure_dirs():
    """Create all required directories if they don't exist. Returns PATHS."""
    dirs = [
        data_dir(), config_dir(), cache_dir(), logs_dir(),
        models_dir(), plugins_dir(), voices_dir(),
        conversations_dir(), proactive_dir(), documents_dir(),
        scripts_dir(), notes_dir(), notebook_dir(),
    ]
    # db_dir only if not dev mode (in dev mode, db_dir == data_dir == artifacts/)
    if not _is_dev_mode():
        dirs.append(db_dir())
    
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
    return PATHS


# ── Backward compatibility aliases ──
# These preserve the API that existing modules expect from the old paths.py

def get_artifacts_dir() -> Path:
    """Backward compat alias."""
    return data_dir()

def get_project_root() -> Path:
    """Backward compat alias."""
    return project_root()

def get_user_db_path() -> Path:
    """Backward compat alias."""
    return user_db_path()

def get_agent_db_path() -> Path:
    """Backward compat alias."""
    return agent_db_path()

def get_models_dir() -> Path:
    """Backward compat alias."""
    return models_dir()

# ── GGUF model path (runtime setting, not a fixed path) ──

_gguf_model_path: str | None = None

def project_root() -> Path:
    return Path(__file__).resolve().parents[2]

def models_root() -> Path:
    return project_root() / "models"

def gguf_models_dir() -> Path:
    return models_root() / "gguf" / "base"

def embedding_models_dir() -> Path:
    return models_root() / "embeddings"

def lora_adapters_dir() -> Path:
    return models_root() / "lora" / "adapters"

def lora_merged_dir() -> Path:
    return models_root() / "lora" / "merged"

def training_root() -> Path:
    return project_root() / "training"

def get_gguf_model_path() -> str | None:
    env = os.environ.get("ELI_GGUF_MODEL_PATH") or os.environ.get("ELI_MODEL")
    if env:
        return env
    if _gguf_model_path:
        return _gguf_model_path
    d = gguf_models_dir()
    if d.exists():
        hits = sorted(d.glob("*.gguf"))
        if hits:
            return str(hits[0])
    return None

def set_gguf_model_path(path: str):
    """Set the GGUF model path at runtime."""
    global _gguf_model_path
    _gguf_model_path = path
    os.environ["ELI_MODEL"] = path


# ── Startup info ──

def path_info() -> dict:
    """Return a dict of all resolved paths for diagnostics."""
    return {
        "project_root": str(project_root()),
        "data_dir": str(data_dir()),
        "config_dir": str(config_dir()),
        "cache_dir": str(cache_dir()),
        "db_dir": str(db_dir()),
        "logs_dir": str(logs_dir()),
        "models_dir": str(models_dir()),
        "voices_dir": str(voices_dir()),
        "plugins_dir": str(plugins_dir()),
        "user_db": str(user_db_path()),
        "agent_db": str(agent_db_path()),
        "is_dev_mode": _is_dev_mode(),
        "is_frozen": is_frozen(),
    }




# ══════════════════════════════════════════════════════════════
# BACKWARD COMPATIBILITY — DO NOT REMOVE
# These exports are used by 30+ modules across the codebase.
# Migrate callers to the new functions above over time.
# ══════════════════════════════════════════════════════════════

class EliPaths:
    """Legacy path object — provides attribute access to all paths."""

    @property
    def project_root(self): return project_root()
    @property
    def root(self): return project_root()
    @property
    def artifacts_dir(self): return data_dir()
    @property
    def data_dir(self): return data_dir()
    @property
    def config_dir(self): return config_dir()
    @property
    def cache_dir(self): return cache_dir()
    @property
    def db_dir(self): return db_dir()
    @property
    def logs_dir(self): return logs_dir()
    @property
    def log_dir(self): return logs_dir()
    @property
    def models_dir(self): return models_dir()
    @property
    def voices_dir(self): return voices_dir()
    @property
    def plugins_dir(self): return plugins_dir()
    @property
    def user_db(self): return user_db_path()
    @property
    def agent_db(self): return agent_db_path()
    @property
    def memory_db(self): return memory_db_path()
    @property
    def knowledge_graph_db(self): return knowledge_graph_db_path()
    @property
    def db(self): return memory_db_path()
    @property
    def conversations_dir(self): return conversations_dir()
    @property
    def proactive_dir(self): return proactive_dir()
    @property
    def documents_dir(self): return documents_dir()
    @property
    def scripts_dir(self): return scripts_dir()
    @property
    def notes_dir(self): return notes_dir()
    @property
    def notebook_dir(self): return notebook_dir()
    @property
    def persona_base(self): return persona_base_path()
    @property
    def persona_auto(self): return persona_auto_path()
    @property
    def model(self): return Path(get_gguf_model_path()).resolve() if get_gguf_model_path() else None

    def __repr__(self):
        return f"EliPaths(root={project_root()}, data={data_dir()}, dev={_is_dev_mode()})"

# Singleton instances used by 30+ modules
PATHS = EliPaths()

def get_paths() -> EliPaths:
    """Return the global PATHS singleton."""
    return PATHS

# Module-level constants for direct import
PROJECT_ROOT = project_root()
ARTIFACTS_DIR = data_dir()
DB_PATH = user_db_path()

def resolve_db_paths():
    """Backward compat — returns object with .user_db, .agent_db, .memory_db as Paths."""
    return PATHS


@lru_cache(maxsize=1)
def canonical_project_root() -> Path:
    return Path(__file__).resolve().parents[2].resolve()

def legacy_repo_alias_root() -> Path:
    return (Path.home() / "eli").resolve(strict=False)

def resolve_user_repo_path(raw_path: str | os.PathLike | None) -> Path:
    """
    Resolve user-facing paths.

    Rules:
    - '~/eli' and '~/eli/...' are treated as a legacy alias for the current repo root.
    - all other paths are expanded normally and resolved non-strictly.
    """
    if raw_path is None:
        return canonical_project_root()

    text = str(raw_path).strip()
    if not text:
        return canonical_project_root()

    expanded = Path(os.path.expanduser(text))
    legacy_root = legacy_repo_alias_root()
    project_root = canonical_project_root()

    try:
        rel = expanded.relative_to(legacy_root)
        return (project_root / rel).resolve(strict=False)
    except ValueError:
        return expanded.resolve(strict=False)

if __name__ == "__main__":
    ensure_dirs()
    info = path_info()
    for k, v in info.items():
        print(f"  {k:20s} = {v}")


# === MKXI_DYNAMIC_DEV_ROOT_OVERRIDE ===
import os as _mkxi_os
from pathlib import Path as _MKXIPath

try:
    _MKXI_ORIG_GET_PATHS = get_paths
except NameError:
    _MKXI_ORIG_GET_PATHS = None

def _mkxi_is_project_root(p: _MKXIPath) -> bool:
    try:
        p = p.expanduser().resolve()
    except Exception:
        return False
    return (
        (p / "eli").is_dir()
        and (p / "config").exists()
        and (p / "bin").exists()
    )

def _mkxi_candidate_project_roots():
    raw = str(_mkxi_os.environ.get("ELI_PROJECT_ROOT", "") or "").strip()
    if raw:
        yield _MKXIPath(raw).expanduser()
    try:
        yield _MKXIPath(__file__).resolve().parents[2]
    except Exception:
        pass
    try:
        yield _MKXIPath.cwd()
    except Exception:
        pass

def _mkxi_repo_root():
    for cand in _mkxi_candidate_project_roots():
        if _mkxi_is_project_root(cand):
            return cand.expanduser().resolve()
    return None

def _mkxi_apply_repo_defaults(paths):
    root = _mkxi_repo_root()
    if root is None:
        return paths

    art = _MKXIPath(
        str(_mkxi_os.environ.get("ELI_ARTIFACTS_DIR", root / "artifacts"))
    ).expanduser().resolve()

    cfg = _MKXIPath(
        str(_mkxi_os.environ.get("ELI_CONFIG_DIR", root / "config"))
    ).expanduser().resolve()

    mdl = _MKXIPath(
        str(_mkxi_os.environ.get("ELI_MODELS_DIR", root / "models/gguf/base"))
    ).expanduser().resolve()

    dbd = _MKXIPath(
        str(
            _mkxi_os.environ.get(
                "ELI_DB_DIR",
                _MKXIPath.home() / ".local" / "share" / "eli" / "db"
            )
        )
    ).expanduser().resolve()

    for d in (art, cfg, mdl, dbd):
        try:
            d.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

    mapping = {
        "project_root": root,
        "artifacts_dir": art,
        "config_dir": cfg,
        "models_dir": mdl,
        "db_dir": dbd,
        "user_db": dbd / "user.sqlite3",
        "agent_db": dbd / "agent.sqlite3",
        "memory_db": dbd / "user.sqlite3",
    }

    for k, v in mapping.items():
        if hasattr(paths, k):
            try:
                setattr(paths, k, v)
            except Exception:
                pass

    return paths

if _MKXI_ORIG_GET_PATHS is not None:
    def get_paths():
        return _mkxi_apply_repo_defaults(_MKXI_ORIG_GET_PATHS())


# === MKXI_DYNAMIC_PROPERTY_OVERRIDE ===
import os as _mkxi_prop_os
from pathlib import Path as _MKXIPath

def _mkxi_prop_repo_root():
    candidates = []

    env_root = str(_mkxi_prop_os.environ.get("ELI_PROJECT_ROOT", "") or "").strip()
    if env_root:
        candidates.append(_MKXIPath(env_root).expanduser())

    try:
        candidates.append(_MKXIPath(__file__).resolve().parents[2])
    except Exception:
        pass

    try:
        candidates.append(_MKXIPath.cwd())
    except Exception:
        pass

    for c in candidates:
        try:
            c = c.expanduser().resolve()
            if (c / "eli").is_dir() and (c / "bin").exists() and (c / "config").exists():
                return c
        except Exception:
            pass
    return None

def _mkxi_prop_artifacts_dir():
    raw = str(_mkxi_prop_os.environ.get("ELI_ARTIFACTS_DIR", "") or "").strip()
    if raw:
        return _MKXIPath(raw).expanduser().resolve()
    root = _mkxi_prop_repo_root()
    if root is not None:
        return (root / "artifacts").resolve()
    return Path(os.environ.get("ELI_ARTIFACTS_DIR", str(_mkxi_prop_project_root() / "artifacts"))).resolve()

def _mkxi_prop_config_dir():
    raw = str(_mkxi_prop_os.environ.get("ELI_CONFIG_DIR", "") or "").strip()
    if raw:
        return _MKXIPath(raw).expanduser().resolve()
    root = _mkxi_prop_repo_root()
    if root is not None:
        return (root / "config").resolve()
    return Path(os.environ.get("ELI_CONFIG_DIR", str(_mkxi_prop_project_root() / "config"))).resolve()

def _mkxi_prop_models_dir():
    raw = str(_mkxi_prop_os.environ.get("ELI_MODELS_DIR", "") or "").strip()
    if raw:
        return _MKXIPath(raw).expanduser().resolve()
    root = _mkxi_prop_repo_root()
    if root is not None:
        return (root / "models" / "gguf" / "base").resolve()
    return Path(os.environ.get("ELI_MODELS_DIR", str(_mkxi_prop_project_root() / "models" / "gguf" / "base"))).resolve()

def _mkxi_prop_db_dir():
    raw = str(_mkxi_prop_os.environ.get("ELI_DB_DIR", "") or "").strip()
    if raw:
        return _MKXIPath(raw).expanduser().resolve()
    return Path(os.environ.get("ELI_DB_DIR", str(_mkxi_prop_project_root() / "artifacts" / "db"))).resolve()

def _mkxi_prop_user_db():
    raw = str(_mkxi_prop_os.environ.get("ELI_USER_DB", "") or "").strip()
    if raw:
        return _MKXIPath(raw).expanduser().resolve()
    return Path(os.environ.get("ELI_MEMORY_DB", os.environ.get("ELI_MEMORY_DB_PATH", str(_mkxi_prop_db_dir() / "user.sqlite3")))).resolve()

def _mkxi_prop_agent_db():
    raw = str(_mkxi_prop_os.environ.get("ELI_AGENT_DB", "") or "").strip()
    if raw:
        return _MKXIPath(raw).expanduser().resolve()
    return Path(os.environ.get("ELI_AGENT_DB", str(_mkxi_prop_db_dir() / "agent.sqlite3"))).resolve()

def _mkxi_prop_memory_db():
    raw = str(_mkxi_prop_os.environ.get("ELI_MEMORY_DB_PATH", "") or "").strip()
    if raw:
        return _MKXIPath(raw).expanduser().resolve()
    return _mkxi_prop_user_db()

try:
    _MKXI_PRE_PROP_GET_PATHS = get_paths
except NameError:
    _MKXI_PRE_PROP_GET_PATHS = None

_MKXI_PATHS_CLASS = None
if _MKXI_PRE_PROP_GET_PATHS is not None:
    try:
        _MKXI_PATHS_CLASS = type(_MKXI_PRE_PROP_GET_PATHS())
    except Exception:
        _MKXI_PATHS_CLASS = None

def _mkxi_patch_property(name, fn):
    global _MKXI_PATHS_CLASS
    if _MKXI_PATHS_CLASS is None:
        return False
    try:
        cur = getattr(_MKXI_PATHS_CLASS, name, None)
        if isinstance(cur, property):
            setattr(_MKXI_PATHS_CLASS, name, property(lambda self, _fn=fn: _fn()))
            return True
    except Exception:
        pass
    return False

for _name, _fn in (
    ("project_root", _mkxi_prop_repo_root),
    ("artifacts_dir", _mkxi_prop_artifacts_dir),
    ("config_dir", _mkxi_prop_config_dir),
    ("models_dir", _mkxi_prop_models_dir),
    ("db_dir", _mkxi_prop_db_dir),
    ("user_db", _mkxi_prop_user_db),
    ("agent_db", _mkxi_prop_agent_db),
    ("memory_db", _mkxi_prop_memory_db),
):
    _mkxi_patch_property(_name, _fn)

if _MKXI_PRE_PROP_GET_PATHS is not None:
    def get_paths():
        p = _MKXI_PRE_PROP_GET_PATHS()
        try:
            root = _mkxi_prop_repo_root()
            if root is not None and not isinstance(getattr(type(p), "project_root", None), property):
                setattr(p, "project_root", root)
        except Exception:
            pass
        for _name, _fn in (
            ("artifacts_dir", _mkxi_prop_artifacts_dir),
            ("config_dir", _mkxi_prop_config_dir),
            ("models_dir", _mkxi_prop_models_dir),
            ("db_dir", _mkxi_prop_db_dir),
            ("user_db", _mkxi_prop_user_db),
            ("agent_db", _mkxi_prop_agent_db),
            ("memory_db", _mkxi_prop_memory_db),
        ):
            try:
                if not isinstance(getattr(type(p), _name, None), property):
                    setattr(p, _name, _fn())
            except Exception:
                pass
        return p


"""
Database path resolution — delegates to core.paths.
Kept for backward compatibility; import from eli.core.paths directly in new code.
"""
from eli.core.paths import (
    project_root, data_dir, user_db_path, agent_db_path,
    memory_db_path, get_gguf_model_path, set_gguf_model_path,
)

# Backward compat: some modules import DBPaths class
class DBPaths:
    """Legacy compatibility wrapper."""
    
    @staticmethod
    def project_root():
        return project_root()
    
    @staticmethod
    def artifacts_dir():
        return data_dir()
    
    @staticmethod
    def user_db():
        return user_db_path()
    
    @staticmethod
    def agent_db():
        return agent_db_path()
    
    @staticmethod
    def memory_db():
        return memory_db_path()

# Function-style aliases for backward compat
def get_user_db_path():
    return user_db_path()

def get_agent_db_path():
    return agent_db_path()

def get_memory_db_path():
    return memory_db_path()

# === MKXI_PHASEAE_CANONICAL_CORE_DBPATHS ===
try:
    from pathlib import Path as _MKXI_PHASEAE_Path

    def _mkxi_phaseae_project_root():
        return _MKXI_PHASEAE_Path(__file__).resolve().parents[2]

    def _mkxi_phaseae_dbdir():
        _dbdir = _mkxi_phaseae_project_root() / "artifacts" / "db"
        _dbdir.mkdir(parents=True, exist_ok=True)
        return _dbdir

    def user_db_path():
        return str((_mkxi_phaseae_dbdir() / "user.sqlite3").resolve())

    def agent_db_path():
        return str((_mkxi_phaseae_dbdir() / "agent.sqlite3").resolve())

    def memory_db_path():
        _memory = (_mkxi_phaseae_dbdir() / "eli_memory.sqlite3").resolve()
        return str(_memory if _memory.exists() else (_mkxi_phaseae_dbdir() / "user.sqlite3").resolve())

    def get_user_db_path():
        return user_db_path()

    def get_agent_db_path():
        return agent_db_path()

    def get_memory_db_path():
        return memory_db_path()

    def get_db_paths(*args, **kwargs):
        return {
            "project_root": str(_mkxi_phaseae_project_root()),
            "user_db": user_db_path(),
            "agent_db": agent_db_path(),
            "memory_db": memory_db_path(),
        }
except Exception as _e:
    print(f"[MKXI_PHASEAE] core.db_paths override failed: {_e}")

# === MKXI_PHASEAF_DBPATHS_OBJECT_FIX ===
try:
    from pathlib import Path as _MKXI_PHASEAF_Path

    class _MKXI_PHASEAF_DBPaths(dict):
        def __getattr__(self, key):
            try:
                return self[key]
            except KeyError as _e:
                raise AttributeError(key) from _e
        __setattr__ = dict.__setitem__

    def _mkxi_phaseaf_root():
        return _MKXI_PHASEAF_Path(__file__).resolve().parents[2]

    def _mkxi_phaseaf_build_dbpaths():
        _root = _mkxi_phaseaf_root()
        _dbdir = (_root / "artifacts" / "db")
        _dbdir.mkdir(parents=True, exist_ok=True)
        _user = (_dbdir / "user.sqlite3").resolve()
        _agent = (_dbdir / "agent.sqlite3").resolve()
        _memory = (_dbdir / "eli_memory.sqlite3").resolve()
        if not _memory.exists():
            _memory = _user
        return _MKXI_PHASEAF_DBPaths(
            project_root=str(_root),
            user_db=str(_user),
            agent_db=str(_agent),
            memory_db=str(_memory),
        )

    def get_db_paths(*args, **kwargs):
        return _mkxi_phaseaf_build_dbpaths()

    def user_db_path():
        return get_db_paths().user_db

    def agent_db_path():
        return get_db_paths().agent_db

    def memory_db_path():
        return get_db_paths().memory_db

    def get_user_db_path():
        return user_db_path()

    def get_agent_db_path():
        return agent_db_path()

    def get_memory_db_path():
        return memory_db_path()

    DB_PATHS = get_db_paths()
except Exception as _e:
    print(f"[MKXI_PHASEAF] core db_paths object fix failed: {_e}")
